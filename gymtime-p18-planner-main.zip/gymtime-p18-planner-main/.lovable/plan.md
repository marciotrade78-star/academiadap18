## 1. Desabilitar slots de horário já passados

Em `src/routes/_authenticated.app.$gym.tsx`:
- Calcular hora atual (timezone São Paulo); re-render a cada 60s via `useState` + `setInterval`.
- Slot é "passado" quando `slot_start <= agora`.
- Slots passados: `disabled`, `opacity-50`, sem hover, status "Horário encerrado".
- Card da reserva do usuário continua visível, mas o botão Cancelar fica desabilitado depois que o horário começa.

## 2. Check-in via leitura de QR Code dentro do app

No card "Sua reserva", botão **Confirmar presença** ao lado de Cancelar, visível quando há reserva hoje e ainda não houve check-in.

Ao clicar, abre modal fullscreen com a câmera traseira do celular usando `html5-qrcode` (`bun add html5-qrcode`):
1. Usuário aponta para o QR colado na porta da academia.
2. App extrai o segmento `gym` da URL lida (`/app/checkin/musculacao` ou `/app/checkin/aerobica`).
3. Se for o QR da outra academia → toast "QR Code da academia errada" e continua escaneando.
4. Se for o correto → chama `supabase.rpc("check_in_booking", { _gym })` (RPC já existente, valida janela de tempo e duplicidade).
5. Fecha câmera, mostra mensagem de resultado (Confirmado / Já confirmado / Fora do horário / Sem reserva) e invalida queries.

Buscar `checked_in_at` no query `my-bookings`; quando preenchido, esconder o botão e exibir badge "Presença confirmada".

A rota `/app/checkin/:gym` permanece para quem escaneia pelo app de câmera nativo.

## Componente novo

`src/components/CheckinScanner.tsx` — modal com câmera, props `gym`, `onClose`, `onSuccess`. Pede permissão; se negada, mostra instrução.

## Arquivos alterados

- `src/routes/_authenticated.app.$gym.tsx`
- `src/components/CheckinScanner.tsx` (novo)
- `package.json` / `bun.lock` (`html5-qrcode`)

Sem alteração no banco.
