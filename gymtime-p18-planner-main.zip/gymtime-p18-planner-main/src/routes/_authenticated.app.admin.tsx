import { createFileRoute, redirect } from "@tanstack/react-router";
import { supabase } from "@/integrations/supabase/client";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { todayISO, generateSlots, GYMS } from "@/lib/slots";
import { Trash2, Dumbbell, Waves, ShieldCheck, Users, Building2, Plus, QrCode, Printer, Download, MessageSquare, CheckCircle2, Lightbulb, Bug, RotateCcw, ChevronDown, ChevronRight, UserCog, Search, Pencil, Check, X } from "lucide-react";
import { ScrollArea } from "@/components/ui/scroll-area";
import { toast } from "sonner";
import { useEffect, useState } from "react";
import QRCode from "qrcode";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { AnnouncementsAdmin } from "@/components/AnnouncementsAdmin";

const PUBLIC_URL = "https://gymtime-p18-planner.lovable.app";

export const Route = createFileRoute("/_authenticated/app/admin")({
  beforeLoad: async ({ context }) => {
    const { data } = await supabase
      .from("user_roles").select("role").eq("user_id", context.user.id).eq("role", "admin").maybeSingle();
    if (!data) throw redirect({ to: "/app" });
  },
  component: AdminPage,
});

const slots = generateSlots();

function AdminPage() {
  const qc = useQueryClient();
  const [date, setDate] = useState(todayISO());
  const [companiesOpen, setCompaniesOpen] = useState(false);
  const [qrOpen, setQrOpen] = useState(false);
  const [siteQrOpen, setSiteQrOpen] = useState(false);
  const [gymOpen, setGymOpen] = useState<Record<string, boolean>>(
    Object.fromEntries(GYMS.map((g) => [g.value, false])),
  );

  const { data: bookings = [], isLoading } = useQuery({
    queryKey: ["admin-bookings", date],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("bookings")
        .select("id, gym, slot_start, user_id, checked_in_at")
        .eq("booking_date", date)
        .order("slot_start");
      if (error) throw error;
      const ids = Array.from(new Set((data ?? []).map((b) => b.user_id)));
      let profilesMap = new Map<string, { nome: string; matricula: string; email: string; company_id: string | null }>();
      if (ids.length) {
        const { data: profs, error: e2 } = await supabase
          .from("profiles")
          .select("id, nome, matricula, email, company_id")
          .in("id", ids);
        if (e2) throw e2;
        profilesMap = new Map((profs ?? []).map((p) => [p.id, { nome: p.nome, matricula: p.matricula, email: p.email, company_id: p.company_id }]));
      }
      return (data ?? []).map((b) => ({ ...b, profiles: profilesMap.get(b.user_id) ?? null }));
    },
  });

  const { data: usersCount = 0 } = useQuery({
    queryKey: ["admin-users-count"],
    queryFn: async () => {
      const { count, error } = await supabase
        .from("profiles")
        .select("*", { count: "exact", head: true });
      if (error) throw error;
      return count ?? 0;
    },
  });

  const { data: companies = [] } = useQuery({
    queryKey: ["admin-companies"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("companies")
        .select("id, nome")
        .order("nome");
      if (error) throw error;
      return data;
    },
  });

  const [newCompany, setNewCompany] = useState("");
  const addCompany = useMutation({
    mutationFn: async (nome: string) => {
      const { error } = await supabase.from("companies").insert({ nome: nome.trim() });
      if (error) throw error;
    },
    onSuccess: () => { toast.success("Empresa cadastrada."); setNewCompany(""); qc.invalidateQueries({ queryKey: ["admin-companies"] }); },
    onError: (e: Error) => toast.error(e.message.includes("duplicate") ? "Empresa já existe." : "Erro ao cadastrar."),
  });
  const delCompany = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("companies").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => { toast.success("Empresa removida."); qc.invalidateQueries({ queryKey: ["admin-companies"] }); },
    onError: () => toast.error("Erro ao remover."),
  });
  const [editingCompanyId, setEditingCompanyId] = useState<string | null>(null);
  const [editingCompanyName, setEditingCompanyName] = useState("");
  const updateCompany = useMutation({
    mutationFn: async ({ id, nome }: { id: string; nome: string }) => {
      const { error } = await supabase.from("companies").update({ nome: nome.trim() }).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Empresa atualizada.");
      setEditingCompanyId(null);
      setEditingCompanyName("");
      qc.invalidateQueries({ queryKey: ["admin-companies"] });
    },
    onError: (e: Error) => toast.error(e.message.includes("duplicate") ? "Empresa já existe." : "Erro ao atualizar."),
  });

  const del = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("bookings").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => { toast.success("Reserva removida."); qc.invalidateQueries(); },
    onError: () => toast.error("Erro ao remover."),
  });

  const [noShowsOpen, setNoShowsOpen] = useState(false);
  const [checkinsOpen, setCheckinsOpen] = useState(false);
  const [confirmDialog, setConfirmDialog] = useState<{ open: boolean; nome: string; slot: string; id: string | null }>({
    open: false,
    nome: "",
    slot: "",
    id: null,
  });

  const byGym = (g: string) => bookings.filter((b) => b.gym === g);
  const totalSlots = slots.length;

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div>
          <div className="inline-flex items-center gap-2 text-xs font-mono uppercase tracking-widest text-primary">
            <ShieldCheck className="size-4" /> Admin
          </div>
          <h1 className="mt-1 text-2xl font-bold tracking-tight">Reservas</h1>
        </div>
        <div className="flex items-center gap-3">
          <div className="panel px-3 py-2 flex items-center gap-2 text-sm">
            <Users className="size-4 text-primary" />
            <span className="font-semibold">{usersCount}</span>
            <span className="text-muted-foreground">usuário{usersCount === 1 ? "" : "s"} cadastrado{usersCount === 1 ? "" : "s"}</span>
          </div>
          <input
            type="date"
            value={date}
            onChange={(e) => setDate(e.target.value)}
            className="rounded-md border border-border bg-input px-3 py-2 text-sm"
          />
        </div>
      </div>

      <section className="panel p-4">
        <header className="flex items-center justify-between mb-3">
          <h2 className="inline-flex items-center gap-2 font-bold text-primary">
            <Building2 className="size-4" /> Empresas
          </h2>
          <div className="flex items-center gap-2">
            <span className="font-mono text-xs text-muted-foreground">{companies.length}</span>
            <button
              type="button"
              onClick={() => setCompaniesOpen((v) => !v)}
              className="p-1.5 rounded-md hover:bg-muted text-muted-foreground"
              aria-label={companiesOpen ? "Recolher" : "Expandir"}
            >
              {companiesOpen ? <ChevronDown className="size-4" /> : <ChevronRight className="size-4" />}
            </button>
          </div>
        </header>
        {companiesOpen && (
          <>
            <form
              onSubmit={(e) => { e.preventDefault(); if (newCompany.trim().length >= 2) addCompany.mutate(newCompany); }}
              className="flex flex-wrap items-center gap-2 mb-3"
            >
              <input
                value={newCompany}
                onChange={(e) => setNewCompany(e.target.value)}
                placeholder="Nome da empresa"
                maxLength={120}
                className="flex-1 rounded-md border border-border bg-input px-3 py-2 text-sm"
              />
              <button
                type="submit"
                disabled={addCompany.isPending || newCompany.trim().length < 2}
                className="inline-flex items-center gap-1 rounded-md bg-primary px-3 py-2 text-sm font-semibold text-primary-foreground disabled:opacity-50"
              >
                <Plus className="size-4" /> Adicionar
              </button>
            </form>
            <ScrollArea className="h-[240px] mt-2">
              {companies.length === 0 ? (
                <p className="text-sm text-muted-foreground">Nenhuma empresa cadastrada.</p>
              ) : (
                <ul className="divide-y divide-border">
                  {companies.map((c) => {
                    const isEditing = editingCompanyId === c.id;
                    return (
                      <li key={c.id} className="py-2 flex items-center justify-between gap-3">
                        {isEditing ? (
                          <>
                            <input
                              value={editingCompanyName}
                              onChange={(e) => setEditingCompanyName(e.target.value)}
                              maxLength={120}
                              autoFocus
                              className="flex-1 rounded-md border border-border bg-input px-2 py-1 text-sm"
                              onKeyDown={(e) => {
                                if (e.key === "Enter" && editingCompanyName.trim().length >= 2) {
                                  updateCompany.mutate({ id: c.id, nome: editingCompanyName });
                                } else if (e.key === "Escape") {
                                  setEditingCompanyId(null);
                                  setEditingCompanyName("");
                                }
                              }}
                            />
                            <div className="flex items-center gap-1 shrink-0">
                              <button
                                onClick={() => updateCompany.mutate({ id: c.id, nome: editingCompanyName })}
                                disabled={updateCompany.isPending || editingCompanyName.trim().length < 2 || editingCompanyName.trim() === c.nome}
                                className="p-2 rounded-md text-success hover:bg-success/15 disabled:opacity-50"
                                aria-label="Salvar"
                              >
                                <Check className="size-4" />
                              </button>
                              <button
                                onClick={() => { setEditingCompanyId(null); setEditingCompanyName(""); }}
                                className="p-2 rounded-md text-muted-foreground hover:bg-muted"
                                aria-label="Cancelar"
                              >
                                <X className="size-4" />
                              </button>
                            </div>
                          </>
                        ) : (
                          <>
                            <span className="text-sm truncate flex-1">{c.nome}</span>
                            <div className="flex items-center gap-1 shrink-0">
                              <button
                                onClick={() => { setEditingCompanyId(c.id); setEditingCompanyName(c.nome); }}
                                className="p-2 rounded-md text-muted-foreground hover:bg-muted"
                                aria-label="Editar"
                              >
                                <Pencil className="size-4" />
                              </button>
                              <button
                                onClick={() => { if (confirm(`Remover a empresa "${c.nome}"?`)) delCompany.mutate(c.id); }}
                                className="p-2 rounded-md text-destructive hover:bg-destructive/15"
                                aria-label="Remover"
                              >
                                <Trash2 className="size-4" />
                              </button>
                            </div>
                          </>
                        )}
                      </li>
                    );
                  })}
                </ul>
              )}
            </ScrollArea>
          </>
        )}
      </section>

      <AdminRolesSection />

      <CheckinQRCodes open={qrOpen} onToggle={() => setQrOpen((v) => !v)} />

      <SiteQRCode open={siteQrOpen} onToggle={() => setSiteQrOpen((v) => !v)} />

      <AnnouncementsAdmin />

      <FeedbackAdmin />

      {(() => {
        const now = new Date();
        const isToday = date === todayISO();
        const noShows = !isToday ? [] : bookings.filter((b) => {
          if (b.checked_in_at) return false;
          const [hh, mm] = b.slot_start.split(":").map(Number);
          const end = new Date();
          end.setHours(hh, mm + 45, 0, 0);
          return now > end;
        });
        const checkins = !isToday ? [] : bookings.filter((b) => !!b.checked_in_at);
        const companyMap = new Map(companies.map((c) => [c.id, c.nome]));
        return (
          <section className="panel p-4">
            <header className="flex items-center justify-between gap-3 flex-wrap mb-2">
              <div className="min-w-0">
                <h2 className="inline-flex items-center gap-2 font-bold text-primary">
                  <RotateCcw className="size-4" /> Faltas de hoje
                </h2>
                <p className="mt-1 text-xs text-muted-foreground">
                  Reservas de hoje sem check-in cujo horário já passou. Escolha qual usuário deseja remover.
                </p>
              </div>
              <div className="flex items-center gap-2">
                <span className="font-mono text-xs text-muted-foreground">{noShows.length}</span>
                <button
                  type="button"
                  onClick={() => setNoShowsOpen((v) => !v)}
                  className="p-1.5 rounded-md hover:bg-muted text-muted-foreground"
                  aria-label={noShowsOpen ? "Recolher" : "Expandir"}
                >
                  {noShowsOpen ? <ChevronDown className="size-4" /> : <ChevronRight className="size-4" />}
                </button>
              </div>
            </header>
            {noShowsOpen && (
              !isToday ? (
                <p className="text-sm text-muted-foreground">Selecione a data de hoje para ver as faltas.</p>
              ) : noShows.length === 0 ? (
                <p className="text-sm text-muted-foreground">Nenhum usuário faltante.</p>
              ) : (
                <ul className="divide-y divide-border">
                  {noShows.map((b) => {
                    const p = b.profiles;
                    const companyName = p?.company_id ? (companyMap.get(p.company_id) ?? "—") : "—";
                    const gymLabel = GYMS.find((g) => g.value === b.gym)?.label ?? b.gym;
                    return (
                      <li key={b.id} className="py-2.5 flex items-center justify-between gap-3">
                        <div className="min-w-0 flex-1">
                          <p className="text-sm font-semibold truncate">{p?.nome ?? "—"}</p>
                          <p className="text-xs text-muted-foreground truncate">
                            {gymLabel} · {b.slot_start.slice(0, 5)} · {companyName}
                          </p>
                        </div>
                        <button
                          onClick={() => {
                            setConfirmDialog({
                              open: true,
                              nome: p?.nome ?? "este usuário",
                              slot: b.slot_start.slice(0, 5),
                              id: b.id,
                            });
                          }}
                          className="inline-flex items-center gap-1 rounded-md bg-destructive px-2.5 py-1.5 text-xs font-semibold text-destructive-foreground hover:bg-destructive/90 shrink-0"
                          aria-label="Remover falta"
                        >
                          <Trash2 className="size-3.5" /> Remover
                        </button>
                      </li>
                    );
                  })}
                </ul>
              )
            )}
            <AlertDialog open={confirmDialog.open} onOpenChange={(open) => setConfirmDialog((prev) => ({ ...prev, open }))}>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Remover falta?</AlertDialogTitle>
                  <AlertDialogDescription>
                    Deseja remover a falta de <strong>{confirmDialog.nome}</strong> no horário <strong>{confirmDialog.slot}</strong>?
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel onClick={() => setConfirmDialog({ open: false, nome: "", slot: "", id: null })}>Cancelar</AlertDialogCancel>
                  <AlertDialogAction
                    onClick={() => {
                      if (confirmDialog.id) del.mutate(confirmDialog.id);
                      setConfirmDialog({ open: false, nome: "", slot: "", id: null });
                    }}
                  >
                    Sim, remover
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </section>
        );
      })()}

      {(() => {
        const isToday = date === todayISO();
        const checkins = !isToday ? [] : bookings.filter((b) => !!b.checked_in_at);
        const companyMap = new Map(companies.map((c) => [c.id, c.nome]));
        return (
          <section className="panel p-4">
            <header className="flex items-center justify-between gap-3 flex-wrap mb-2">
              <div className="min-w-0">
                <h2 className="inline-flex items-center gap-2 font-bold text-success">
                  <CheckCircle2 className="size-4" /> Check-ins de hoje
                </h2>
                <p className="mt-1 text-xs text-muted-foreground">
                  Reservas de hoje com check-in confirmado. Escolha qual usuário deseja remover.
                </p>
              </div>
              <div className="flex items-center gap-2">
                <span className="font-mono text-xs text-muted-foreground">{checkins.length}</span>
                <button
                  type="button"
                  onClick={() => setCheckinsOpen((v) => !v)}
                  className="p-1.5 rounded-md hover:bg-muted text-muted-foreground"
                  aria-label={checkinsOpen ? "Recolher" : "Expandir"}
                >
                  {checkinsOpen ? <ChevronDown className="size-4" /> : <ChevronRight className="size-4" />}
                </button>
              </div>
            </header>
            {checkinsOpen && (
              !isToday ? (
                <p className="text-sm text-muted-foreground">Selecione a data de hoje para ver os check-ins.</p>
              ) : checkins.length === 0 ? (
                <p className="text-sm text-muted-foreground">Nenhum check-in confirmado.</p>
              ) : (
                <ul className="divide-y divide-border">
                  {checkins.map((b) => {
                    const p = b.profiles;
                    const companyName = p?.company_id ? (companyMap.get(p.company_id) ?? "—") : "—";
                    const gymLabel = GYMS.find((g) => g.value === b.gym)?.label ?? b.gym;
                    return (
                      <li key={b.id} className="py-2.5 flex items-center justify-between gap-3">
                        <div className="min-w-0 flex-1">
                          <p className="text-sm font-semibold truncate">{p?.nome ?? "—"}</p>
                          <p className="text-xs text-muted-foreground truncate">
                            {gymLabel} · {b.slot_start.slice(0, 5)} · {companyName}
                          </p>
                        </div>
                        <button
                          onClick={() => {
                            setConfirmDialog({
                              open: true,
                              nome: p?.nome ?? "este usuário",
                              slot: b.slot_start.slice(0, 5),
                              id: b.id,
                            });
                          }}
                          className="inline-flex items-center gap-1 rounded-md bg-destructive px-2.5 py-1.5 text-xs font-semibold text-destructive-foreground hover:bg-destructive/90 shrink-0"
                          aria-label="Remover check-in"
                        >
                          <Trash2 className="size-3.5" /> Remover
                        </button>
                      </li>
                    );
                  })}
                </ul>
              )
            )}
            <AlertDialog open={confirmDialog.open} onOpenChange={(open) => setConfirmDialog((prev) => ({ ...prev, open }))}>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Remover reserva?</AlertDialogTitle>
                  <AlertDialogDescription>
                    Deseja remover a reserva de <strong>{confirmDialog.nome}</strong> no horário <strong>{confirmDialog.slot}</strong>?
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel onClick={() => setConfirmDialog({ open: false, nome: "", slot: "", id: null })}>Cancelar</AlertDialogCancel>
                  <AlertDialogAction
                    onClick={() => {
                      if (confirmDialog.id) del.mutate(confirmDialog.id);
                      setConfirmDialog({ open: false, nome: "", slot: "", id: null });
                    }}
                  >
                    Sim, remover
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </section>
        );
      })()}






      {GYMS.map((g) => {
        const Icon = g.value === "musculacao" ? Dumbbell : Waves;
        const color = g.value === "musculacao" ? "var(--musc)" : "var(--aero)";
        return (
          <GymSection
            key={g.value}
            gym={g.value}
            label={g.label}
            Icon={Icon}
            color={color}
            bookings={byGym(g.value)}
            companies={companies}
            totalSlots={totalSlots}
            isLoading={isLoading}
            open={gymOpen[g.value] ?? false}
            onToggle={() => setGymOpen((prev) => ({ ...prev, [g.value]: !prev[g.value] }))}
            onDelete={(id) => { if (confirm("Remover esta reserva?")) del.mutate(id); }}
          />
        );
      })}
    </div>
  );
}

type BookingRow = {
  id: string;
  gym: string;
  slot_start: string;
  user_id: string;
  checked_in_at?: string | null;
  profiles: { nome: string; matricula: string; email: string; company_id?: string | null } | null;
};

function GymSection({
  gym, label, Icon, color, bookings, companies, totalSlots, isLoading, open, onToggle, onDelete,
}: {
  gym: string;
  label: string;
  Icon: React.ComponentType<{ className?: string }>;
  color: string;
  bookings: BookingRow[];
  companies: { id: string; nome: string }[];
  totalSlots: number;
  isLoading: boolean;
  open: boolean;
  onToggle: () => void;
  onDelete: (id: string) => void;
}) {
  const [companyFilter, setCompanyFilter] = useState<string>("all");
  const [slotFilter, setSlotFilter] = useState<string>("all");

  const companyMap = new Map(companies.map((c) => [c.id, c.nome]));

  const availableSlots = Array.from(new Set(bookings.map((b) => b.slot_start))).sort();
  const filtered = bookings.filter((b) => {
    if (slotFilter !== "all" && b.slot_start !== slotFilter) return false;
    if (companyFilter !== "all") {
      const cid = b.profiles?.company_id ?? "";
      if (companyFilter === "none") {
        if (cid) return false;
      } else if (cid !== companyFilter) return false;
    }
    return true;
  });

  return (
    <section className="panel p-4">
      <header className="flex items-center justify-between mb-3 gap-2 flex-wrap">
        <h2 className="inline-flex items-center gap-2 font-bold" style={{ color }}>
          <Icon className="size-4" /> {label}
        </h2>
        <div className="flex items-center gap-2">
          <span className="font-mono text-xs text-muted-foreground">{filtered.length}/{bookings.length} · cap. {totalSlots}</span>
          <button
            type="button"
            onClick={onToggle}
            className="p-1.5 rounded-md hover:bg-muted text-muted-foreground"
            aria-label={open ? "Recolher" : "Expandir"}
          >
            {open ? <ChevronDown className="size-4" /> : <ChevronRight className="size-4" />}
          </button>
        </div>
      </header>

      {open && (
        <>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mb-3">
        <label className="flex flex-col gap-1">
          <span className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground">Empresa</span>
          <select
            value={companyFilter}
            onChange={(e) => setCompanyFilter(e.target.value)}
            className="rounded-md border border-border bg-input px-2 py-1.5 text-sm"
          >
            <option value="all">Todas</option>
            <option value="none">Sem empresa</option>
            {companies.map((c) => (
              <option key={c.id} value={c.id}>{c.nome}</option>
            ))}
          </select>
        </label>
        <label className="flex flex-col gap-1">
          <span className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground">Horário</span>
          <select
            value={slotFilter}
            onChange={(e) => setSlotFilter(e.target.value)}
            className="rounded-md border border-border bg-input px-2 py-1.5 text-sm"
          >
            <option value="all">Todos</option>
            {availableSlots.map((s) => (
              <option key={s} value={s}>{s.slice(0, 5)}</option>
            ))}
          </select>
        </label>
      </div>

      {isLoading ? (
        <p className="text-sm text-muted-foreground">Carregando...</p>
      ) : filtered.length === 0 ? (
        <p className="text-sm text-muted-foreground">Nenhuma reserva.</p>
      ) : (
        <ul className="divide-y divide-border">
          {filtered.map((b) => {
            const p = b.profiles;
            const companyName = p?.company_id ? (companyMap.get(p.company_id) ?? "—") : "—";
            const checked = b.checked_in_at;
            const [hh, mm] = b.slot_start.split(":").map(Number);
            const slotEnd = new Date();
            slotEnd.setHours(hh, mm + 45, 0, 0);
            const isPast = new Date() > slotEnd;
            const status = checked
              ? { label: "Confirmado", cls: "bg-success/15 text-success" }
              : isPast
                ? { label: "Falta", cls: "bg-destructive/15 text-destructive" }
                : { label: "Pendente", cls: "bg-muted text-muted-foreground" };
            return (
              <li key={b.id} className="py-2.5 flex items-center justify-between gap-3">
                {/* Mobile: nome, empresa, hora + status */}
                <div className="min-w-0 flex-1 sm:hidden">
                  <p className="text-sm font-semibold truncate">{p?.nome ?? "—"}</p>
                  <p className="text-xs text-muted-foreground truncate">
                    {companyName} · {b.slot_start.slice(0, 5)}
                  </p>
                </div>
                <span className={`sm:hidden text-[10px] font-mono uppercase tracking-widest px-2 py-1 rounded-md shrink-0 ${status.cls}`}>
                  {status.label}
                </span>
                <button
                  onClick={() => onDelete(b.id)}
                  className="sm:hidden p-2 rounded-md text-destructive hover:bg-destructive/15 shrink-0"
                  aria-label="Remover"
                >
                  <Trash2 className="size-4" />
                </button>

                {/* Desktop: layout completo */}
                <div className="hidden sm:block min-w-0 flex-1">
                  <p className="text-sm font-semibold truncate">{p?.nome ?? "—"}</p>
                  <p className="text-xs text-muted-foreground font-mono truncate">
                    {b.slot_start.slice(0, 5)} · {companyName} · {p?.matricula ?? "—"} · {p?.email ?? ""}
                  </p>
                </div>
                <span className={`hidden sm:block text-[10px] font-mono uppercase tracking-widest px-2 py-1 rounded-md ${status.cls}`}>
                  {status.label}
                </span>
                <button
                  onClick={() => onDelete(b.id)}
                  className="hidden sm:block p-2 rounded-md text-destructive hover:bg-destructive/15"
                  aria-label="Remover"
                >
                  <Trash2 className="size-4" />
                </button>
              </li>
            );
          })}
        </ul>
      )}
      </>
      )}
    </section>
  );
}


function CheckinQRCodes({ open, onToggle }: { open: boolean; onToggle: () => void }) {
  const [qrs, setQrs] = useState<Record<string, string>>({});

  useEffect(() => {
    (async () => {
      const out: Record<string, string> = {};
      for (const g of GYMS) {
        const url = `${PUBLIC_URL}/app/checkin/${g.value}`;
        out[g.value] = await QRCode.toDataURL(url, { width: 320, margin: 1 });
      }
      setQrs(out);
    })();
  }, []);

  function printQR(gym: string, label: string, img: string) {
    const w = window.open("", "_blank", "width=600,height=800");
    if (!w) return;
    w.document.write(`<html><head><title>QR ${label}</title><style>body{font-family:system-ui;text-align:center;padding:40px}h1{margin:0 0 8px}p{color:#555;margin:0 0 24px}img{width:380px;height:380px}</style></head><body><h1>Academia ${label}</h1><p>Escaneie para confirmar sua presença</p><img src="${img}"/><p style="margin-top:24px;font-family:monospace;font-size:11px">${PUBLIC_URL}/app/checkin/${gym}</p></body></html>`);
    w.document.close();
    setTimeout(() => w.print(), 300);
  }

  function downloadQR(gym: string, label: string, img: string) {
    const link = document.createElement("a");
    link.href = img;
    link.download = `qr-checkin-${gym}.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }

  return (
    <section className="panel p-4">
      <header className="flex items-center justify-between mb-3">
        <h2 className="inline-flex items-center gap-2 font-bold text-primary">
          <QrCode className="size-4" /> QR Codes de confirmação
        </h2>
        <button
          type="button"
          onClick={onToggle}
          className="p-1.5 rounded-md hover:bg-muted text-muted-foreground"
          aria-label={open ? "Recolher" : "Expandir"}
        >
          {open ? <ChevronDown className="size-4" /> : <ChevronRight className="size-4" />}
        </button>
      </header>
      {open && (
        <>
          <p className="text-xs text-muted-foreground mb-4">
            Imprima e fixe na porta de cada academia. Usuários escaneiam para confirmar a presença no horário reservado.
          </p>
          <div className="grid sm:grid-cols-2 gap-4">
        {GYMS.map((g) => {
          const Icon = g.value === "musculacao" ? Dumbbell : Waves;
          const color = g.value === "musculacao" ? "var(--musc)" : "var(--aero)";
          const img = qrs[g.value];
          return (
            <div key={g.value} className="rounded-xl border border-border p-3">
              <div className="flex items-center gap-2 mb-2" style={{ color }}>
                <Icon className="size-4" />
                <span className="font-semibold text-sm">{g.label}</span>
              </div>
              <div className="bg-white rounded-lg p-2 grid place-items-center">
                {img ? <img src={img} alt={`QR ${g.label}`} className="w-44 h-44" /> : <div className="w-44 h-44 grid place-items-center text-muted-foreground"><QrCode className="size-8" /></div>}
              </div>
              <div className="mt-3 flex items-center gap-2">
                <button
                  onClick={() => img && downloadQR(g.value, g.label, img)}
                  disabled={!img}
                  className="flex-1 inline-flex items-center justify-center gap-1.5 rounded-md bg-muted px-3 py-2 text-sm font-semibold text-foreground hover:bg-muted/80 disabled:opacity-50"
                >
                  <Download className="size-4" /> Download
                </button>
                <button
                  onClick={() => img && printQR(g.value, g.label, img)}
                  disabled={!img}
                  className="flex-1 inline-flex items-center justify-center gap-1.5 rounded-md bg-primary px-3 py-2 text-sm font-semibold text-primary-foreground disabled:opacity-50"
                >
                  <Printer className="size-4" /> Imprimir
                </button>
              </div>
            </div>
          );
        })}
      </div>
      </>
      )}
    </section>
  );
}

const SITE_URL = "https://www.academiadap18.com.br/";

function SiteQRCode({ open, onToggle }: { open: boolean; onToggle: () => void }) {
  const [img, setImg] = useState<string>("");

  useEffect(() => {
    QRCode.toDataURL(SITE_URL, { width: 480, margin: 1 }).then(setImg);
  }, []);

  function printQR() {
    const w = window.open("", "_blank", "width=600,height=800");
    if (!w || !img) return;
    w.document.write(`<html><head><title>QR Academia DA P-18</title><style>body{font-family:system-ui;text-align:center;padding:40px}h1{margin:0 0 8px}p{color:#555;margin:0 0 24px}img{width:420px;height:420px}</style></head><body><h1>Academia DA P-18</h1><p>Escaneie para acessar o site</p><img src="${img}"/><p style="margin-top:24px;font-family:monospace;font-size:12px">${SITE_URL}</p></body></html>`);
    w.document.close();
    setTimeout(() => w.print(), 300);
  }

  function downloadQR() {
    if (!img) return;
    const link = document.createElement("a");
    link.href = img;
    link.download = "qr-academiadap18.png";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }

  return (
    <section className="panel p-4">
      <header className="flex items-center justify-between mb-3">
        <h2 className="inline-flex items-center gap-2 font-bold text-primary">
          <QrCode className="size-4" /> QR Code do site
        </h2>
        <button
          type="button"
          onClick={onToggle}
          className="p-1.5 rounded-md hover:bg-muted text-muted-foreground"
          aria-label={open ? "Recolher" : "Expandir"}
        >
          {open ? <ChevronDown className="size-4" /> : <ChevronRight className="size-4" />}
        </button>
      </header>
      {open && (
        <>
          <p className="text-xs text-muted-foreground mb-4">
            QR Code para divulgação do site da academia. Imprima ou baixe a imagem para compartilhar.
          </p>
          <div className="rounded-xl border border-border p-3 max-w-sm mx-auto">
            <div className="bg-white rounded-lg p-3 grid place-items-center">
              {img ? (
                <img src={img} alt="QR Academia DA P-18" className="w-56 h-56" />
              ) : (
                <div className="w-56 h-56 grid place-items-center text-muted-foreground">
                  <QrCode className="size-8" />
                </div>
              )}
            </div>
            <p className="mt-2 text-center font-mono text-[11px] text-muted-foreground break-all">{SITE_URL}</p>
            <div className="mt-3 flex items-center gap-2">
              <button
                onClick={downloadQR}
                disabled={!img}
                className="flex-1 inline-flex items-center justify-center gap-1.5 rounded-md bg-muted px-3 py-2 text-sm font-semibold text-foreground hover:bg-muted/80 disabled:opacity-50"
              >
                <Download className="size-4" /> Download
              </button>
              <button
                onClick={printQR}
                disabled={!img}
                className="flex-1 inline-flex items-center justify-center gap-1.5 rounded-md bg-primary px-3 py-2 text-sm font-semibold text-primary-foreground disabled:opacity-50"
              >
                <Printer className="size-4" /> Imprimir
              </button>
            </div>
          </div>
        </>
      )}
    </section>
  );
}

type FeedbackRow = {
  id: string;
  user_id: string;
  type: "sugestao" | "erro";
  message: string;
  status: "pendente" | "concluido";
  created_at: string;
  completed_at: string | null;
};

function FeedbackAdmin() {
  const qc = useQueryClient();
  const [filter, setFilter] = useState<"pendente" | "concluido">("pendente");

  const { data: feedbacks = [], isLoading } = useQuery({
    queryKey: ["admin-feedback", filter],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("feedback")
        .select("id, user_id, type, message, status, created_at, completed_at")
        .eq("status", filter)
        .order("created_at", { ascending: false });
      if (error) throw error;
      const rows = (data ?? []) as FeedbackRow[];
      const ids = Array.from(new Set(rows.map((r) => r.user_id)));
      let profMap = new Map<string, { nome: string; email: string }>();
      if (ids.length) {
        const { data: profs } = await supabase
          .from("profiles")
          .select("id, nome, email")
          .in("id", ids);
        profMap = new Map((profs ?? []).map((p) => [p.id, { nome: p.nome, email: p.email }]));
      }
      return rows.map((r) => ({ ...r, profile: profMap.get(r.user_id) ?? null }));
    },
  });

  const toggleStatus = useMutation({
    mutationFn: async ({ id, done }: { id: string; done: boolean }) => {
      const { error } = await supabase
        .from("feedback")
        .update({
          status: done ? "concluido" : "pendente",
          completed_at: done ? new Date().toISOString() : null,
        })
        .eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Atualizado.");
      qc.invalidateQueries({ queryKey: ["admin-feedback"] });
    },
    onError: () => toast.error("Erro ao atualizar."),
  });

  const remove = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("feedback").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Removido.");
      qc.invalidateQueries({ queryKey: ["admin-feedback"] });
    },
    onError: () => toast.error("Erro ao remover."),
  });

  return (
    <section className="panel p-4">
      <header className="flex items-center justify-between mb-3 gap-2 flex-wrap">
        <h2 className="inline-flex items-center gap-2 font-bold text-primary">
          <MessageSquare className="size-4" /> Sugestões e erros
        </h2>
        <div className="inline-flex rounded-md border border-border overflow-hidden text-xs font-semibold">
          <button
            onClick={() => setFilter("pendente")}
            className={`px-3 py-1.5 ${filter === "pendente" ? "bg-primary text-primary-foreground" : "bg-background hover:bg-accent"}`}
          >
            Pendentes
          </button>
          <button
            onClick={() => setFilter("concluido")}
            className={`px-3 py-1.5 border-l border-border ${filter === "concluido" ? "bg-primary text-primary-foreground" : "bg-background hover:bg-accent"}`}
          >
            Concluídos
          </button>
        </div>
      </header>

      {isLoading ? (
        <p className="text-sm text-muted-foreground">Carregando...</p>
      ) : feedbacks.length === 0 ? (
        <p className="text-sm text-muted-foreground">
          {filter === "pendente" ? "Nenhum feedback pendente." : "Nenhum feedback concluído."}
        </p>
      ) : (
        <ul className="space-y-2">
          {feedbacks.map((f) => {
            const isErro = f.type === "erro";
            const TypeIcon = isErro ? Bug : Lightbulb;
            const typeCls = isErro ? "bg-destructive/15 text-destructive" : "bg-primary/15 text-primary";
            return (
              <li key={f.id} className="rounded-lg border border-border p-3">
                <div className="flex items-start justify-between gap-2 flex-wrap">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className={`inline-flex items-center gap-1 text-[10px] font-mono uppercase tracking-widest px-2 py-1 rounded-md ${typeCls}`}>
                      <TypeIcon className="size-3" /> {isErro ? "Erro" : "Sugestão"}
                    </span>
                    <span className="text-xs text-muted-foreground">
                      {f.profile?.nome ?? "—"} · {new Date(f.created_at).toLocaleString("pt-BR")}
                    </span>
                  </div>
                  <div className="flex items-center gap-1">
                    {f.status === "pendente" ? (
                      <button
                        onClick={() => toggleStatus.mutate({ id: f.id, done: true })}
                        className="inline-flex items-center gap-1 rounded-md bg-success/15 text-success px-2 py-1 text-xs font-semibold hover:bg-success/25"
                      >
                        <CheckCircle2 className="size-3.5" /> Concluir
                      </button>
                    ) : (
                      <button
                        onClick={() => toggleStatus.mutate({ id: f.id, done: false })}
                        className="inline-flex items-center gap-1 rounded-md bg-muted text-foreground px-2 py-1 text-xs font-semibold hover:bg-muted/80"
                      >
                        <RotateCcw className="size-3.5" /> Reabrir
                      </button>
                    )}
                    <button
                      onClick={() => { if (confirm("Remover este feedback?")) remove.mutate(f.id); }}
                      className="p-1.5 rounded-md text-destructive hover:bg-destructive/15"
                      aria-label="Remover"
                    >
                      <Trash2 className="size-3.5" />
                    </button>
                  </div>
                </div>
                <p className="mt-2 text-sm whitespace-pre-wrap break-words">{f.message}</p>
                {f.profile?.email && (
                  <p className="mt-1 text-[11px] font-mono text-muted-foreground">{f.profile.email}</p>
                )}
              </li>
            );
          })}
        </ul>
      )}
    </section>
  );
}

function AdminRolesSection() {
  const qc = useQueryClient();
  const [open, setOpen] = useState(true);
  const [search, setSearch] = useState("");
  const [confirm, setConfirm] = useState<{ open: boolean; nome: string; userId: string | null; action: "grant" | "revoke" }>({
    open: false,
    nome: "",
    userId: null,
    action: "grant",
  });

  const { data: currentUserId } = useQuery({
    queryKey: ["current-user-id"],
    queryFn: async () => {
      const { data } = await supabase.auth.getUser();
      return data.user?.id ?? null;
    },
  });

  const { data: profiles = [] } = useQuery({
    queryKey: ["admin-profiles-roles"],
    queryFn: async () => {
      const { data: profs, error } = await supabase
        .from("profiles")
        .select("id, nome, matricula, email")
        .order("nome");
      if (error) throw error;
      const { data: roles, error: e2 } = await supabase
        .from("user_roles")
        .select("user_id, role")
        .eq("role", "admin");
      if (e2) throw e2;
      const adminSet = new Set((roles ?? []).map((r) => r.user_id));
      return (profs ?? []).map((p) => ({ ...p, isAdmin: adminSet.has(p.id) }));
    },
    enabled: open,
  });

  const grant = useMutation({
    mutationFn: async (userId: string) => {
      const { error } = await supabase.from("user_roles").insert({ user_id: userId, role: "admin" });
      if (error) throw error;
    },
    onSuccess: () => { toast.success("Usuário promovido a administrador."); qc.invalidateQueries({ queryKey: ["admin-profiles-roles"] }); },
    onError: (e: Error) => toast.error(e.message.includes("duplicate") ? "Já é administrador." : "Erro ao promover."),
  });

  const revoke = useMutation({
    mutationFn: async (userId: string) => {
      const { error } = await supabase.from("user_roles").delete().eq("user_id", userId).eq("role", "admin");
      if (error) throw error;
    },
    onSuccess: () => { toast.success("Permissão de administrador removida."); qc.invalidateQueries({ queryKey: ["admin-profiles-roles"] }); },
    onError: () => toast.error("Erro ao remover permissão."),
  });

  const q = search.trim().toLowerCase();
  const filtered = q
    ? profiles.filter((p) =>
        p.nome?.toLowerCase().includes(q) ||
        p.email?.toLowerCase().includes(q) ||
        p.matricula?.toLowerCase().includes(q)
      )
    : profiles;
  const adminCount = profiles.filter((p) => p.isAdmin).length;

  return (
    <section className="panel p-4">
      <header className="flex items-center justify-between mb-3">
        <h2 className="inline-flex items-center gap-2 font-bold text-primary">
          <UserCog className="size-4" /> Administradores
        </h2>
        <div className="flex items-center gap-2">
          {open && <span className="font-mono text-xs text-muted-foreground">{adminCount} admin{adminCount === 1 ? "" : "s"}</span>}
          <button
            type="button"
            onClick={() => setOpen((v) => !v)}
            className="p-1.5 rounded-md hover:bg-muted text-muted-foreground"
            aria-label={open ? "Recolher" : "Expandir"}
          >
            {open ? <ChevronDown className="size-4" /> : <ChevronRight className="size-4" />}
          </button>
        </div>
      </header>
      {open && (
        <>
          <p className="text-xs text-muted-foreground mb-3">
            Promova ou rebaixe usuários. Você não pode remover seu próprio acesso.
          </p>
          <div className="relative mb-3">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Buscar por nome, e-mail ou matrícula"
              className="w-full rounded-md border border-border bg-input pl-9 pr-3 py-2 text-sm"
            />
          </div>
          <ScrollArea className="h-[320px]">
            {filtered.length === 0 ? (
              <p className="text-sm text-muted-foreground">Nenhum usuário encontrado.</p>
            ) : (
              <ul className="divide-y divide-border">
                {filtered.map((p) => {
                  const isSelf = p.id === currentUserId;
                  return (
                    <li key={p.id} className="grid gap-2 py-2.5 sm:flex sm:items-center sm:justify-between sm:gap-3">
                      <div className="min-w-0 sm:flex-1">
                        <div className="flex items-center gap-2">
                          <p className="text-sm font-semibold truncate">{p.nome}</p>
                          {p.isAdmin && (
                            <span className="inline-flex items-center gap-1 rounded-full bg-primary/15 text-primary px-2 py-0.5 text-[10px] font-mono uppercase tracking-wider shrink-0">
                              <ShieldCheck className="size-3" /> admin
                            </span>
                          )}
                        </div>
                        <p className="text-xs text-muted-foreground truncate">{p.email} · {p.matricula}</p>
                      </div>
                      {p.isAdmin ? (
                        <button
                          disabled={isSelf}
                          onClick={() => setConfirm({ open: true, nome: p.nome, userId: p.id, action: "revoke" })}
                          className="inline-flex w-full items-center justify-center gap-1 rounded-md bg-destructive px-2.5 py-1.5 text-xs font-semibold text-destructive-foreground hover:bg-destructive/90 disabled:cursor-not-allowed disabled:opacity-50 sm:w-auto sm:shrink-0"
                          title={isSelf ? "Você não pode remover seu próprio acesso" : "Remover admin"}
                          aria-label={isSelf ? "Você não pode remover seu próprio acesso" : "Remover admin"}
                        >
                          Remover admin
                        </button>
                      ) : (
                        <button
                          onClick={() => setConfirm({ open: true, nome: p.nome, userId: p.id, action: "grant" })}
                          className="inline-flex w-full items-center justify-center gap-1 rounded-md bg-primary px-2.5 py-1.5 text-xs font-semibold text-primary-foreground hover:bg-primary/90 sm:w-auto sm:shrink-0"
                          title="Tornar admin"
                          aria-label="Tornar admin"
                        >
                          <ShieldCheck className="size-3.5" />
                          Tornar admin
                        </button>
                      )}
                    </li>
                  );
                })}
              </ul>
            )}
          </ScrollArea>
        </>
      )}
      <AlertDialog open={confirm.open} onOpenChange={(o) => setConfirm((prev) => ({ ...prev, open: o }))}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>
              {confirm.action === "grant" ? "Promover a administrador?" : "Remover permissão de administrador?"}
            </AlertDialogTitle>
            <AlertDialogDescription>
              {confirm.action === "grant" ? (
                <>Deseja conceder acesso de administrador para <strong>{confirm.nome}</strong>?</>
              ) : (
                <>Deseja remover o acesso de administrador de <strong>{confirm.nome}</strong>?</>
              )}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => setConfirm({ open: false, nome: "", userId: null, action: "grant" })}>Cancelar</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => {
                if (confirm.userId) {
                  if (confirm.action === "grant") grant.mutate(confirm.userId);
                  else revoke.mutate(confirm.userId);
                }
                setConfirm({ open: false, nome: "", userId: null, action: "grant" });
              }}
            >
              Confirmar
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </section>
  );
}
