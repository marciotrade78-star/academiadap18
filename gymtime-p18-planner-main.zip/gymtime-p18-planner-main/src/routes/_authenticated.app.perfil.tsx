import { createFileRoute, useRouter } from "@tanstack/react-router";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import { User as UserIcon, Save, Camera, Upload } from "lucide-react";
import { AvatarCropper } from "@/components/AvatarCropper";
import { InstallAppSection } from "@/components/InstallAppSection";
import { PrivacyPortal } from "@/components/PrivacyPortal";

export const Route = createFileRoute("/_authenticated/app/perfil")({
  component: PerfilPage,
});

function PerfilPage() {
  const { user } = Route.useRouteContext();
  const router = useRouter();
  const queryClient = useQueryClient();

  const { data: profile, isLoading } = useQuery({
    queryKey: ["profile", user.id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("profiles")
        .select("id, nome, matricula, email, company_id, avatar_url")
        .eq("id", user.id)
        .maybeSingle();
      if (error) throw error;
      return data;
    },
  });

  const { data: companies = [] } = useQuery({
    queryKey: ["companies"],
    queryFn: async () => {
      const { data, error } = await supabase.from("companies").select("id, nome").order("nome");
      if (error) throw error;
      return data ?? [];
    },
  });

  const { data: avatarUrl } = useQuery({
    queryKey: ["avatar-signed", profile?.avatar_url],
    enabled: !!profile?.avatar_url,
    queryFn: async () => {
      const { data, error } = await supabase.storage
        .from("avatars")
        .createSignedUrl(profile!.avatar_url as string, 60 * 60);
      if (error) throw error;
      return data.signedUrl;
    },
  });

  const [nome, setNome] = useState("");
  const [matricula, setMatricula] = useState("");
  const [companyId, setCompanyId] = useState<string>("");
  const [localPreview, setLocalPreview] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);
  const [pendingFile, setPendingFile] = useState<File | null>(null);

  useEffect(() => {
    if (profile) {
      setNome(profile.nome ?? "");
      setMatricula(profile.matricula ?? "");
      setCompanyId(profile.company_id ?? "");
    }
  }, [profile]);

  useEffect(() => {
    return () => {
      if (localPreview) URL.revokeObjectURL(localPreview);
    };
  }, [localPreview]);

  const uploadMutation = useMutation({
    mutationFn: async (file: File) => {
      const mime = file.type || "image/jpeg";
      if (!mime.startsWith("image/")) throw new Error("Selecione uma imagem.");
      if (file.size > 5 * 1024 * 1024) throw new Error("Imagem muito grande (máx. 5MB).");
      const ext = (file.name.split(".").pop() || mime.split("/")[1] || "jpg").toLowerCase();
      const path = `${user.id}/avatar-${Date.now()}.${ext}`;
      const { error: upErr } = await supabase.storage
        .from("avatars")
        .upload(path, file, { upsert: true, contentType: mime });
      if (upErr) throw upErr;
      if (profile?.avatar_url && profile.avatar_url !== path) {
        await supabase.storage.from("avatars").remove([profile.avatar_url]);
      }
      const { error: updErr } = await supabase
        .from("profiles")
        .update({ avatar_url: path })
        .eq("id", user.id);
      if (updErr) throw updErr;
    },
    onSuccess: () => {
      toast.success("Foto atualizada.");
      queryClient.invalidateQueries({ queryKey: ["profile", user.id] });
    },
    onError: (e: Error) => {
      console.error("avatar upload failed", e);
      toast.error(e.message || "Falha ao enviar foto.");
      setLocalPreview(null);
    },
  });

  const handleFile = (f: File | undefined) => {
    if (!f) return;
    setPendingFile(f);
  };

  const handleCropConfirm = (cropped: File) => {
    const url = URL.createObjectURL(cropped);
    setLocalPreview((prev) => {
      if (prev) URL.revokeObjectURL(prev);
      return url;
    });
    setPendingFile(null);
    uploadMutation.mutate(cropped);
  };

  const saveMutation = useMutation({
    mutationFn: async () => {
      const trimmedNome = nome.trim();
      const trimmedMatricula = matricula.trim();
      if (!trimmedNome) throw new Error("Informe seu nome.");
      if (trimmedNome.length > 100) throw new Error("Nome muito longo.");
      if (!trimmedMatricula) throw new Error("Informe sua matrícula.");
      if (trimmedMatricula.length > 50) throw new Error("Matrícula muito longa.");

      const { error } = await supabase
        .from("profiles")
        .update({
          nome: trimmedNome,
          matricula: trimmedMatricula,
          company_id: companyId || null,
        })
        .eq("id", user.id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Perfil atualizado.");
      queryClient.invalidateQueries({ queryKey: ["profile", user.id] });
      router.navigate({ to: "/app" });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  if (isLoading) {
    return <p className="text-sm text-muted-foreground">Carregando...</p>;
  }

  const initials = (nome || profile?.email || "?").trim().charAt(0).toUpperCase();

  return (
    <div className="space-y-6 max-w-lg">
      <section>
        <div className="inline-flex items-center gap-2 text-xs font-mono uppercase tracking-widest text-muted-foreground">
          <UserIcon className="size-4" /> Perfil
        </div>
        <h1 className="mt-1 text-2xl font-bold tracking-tight">Editar perfil</h1>
        <p className="text-sm text-muted-foreground mt-1">Atualize seus dados pessoais.</p>
      </section>

      <div className="panel p-5 flex items-center gap-4">
        <div className="size-24 rounded-full bg-muted border border-border overflow-hidden flex items-center justify-center text-2xl font-bold text-muted-foreground shrink-0">
          {localPreview || avatarUrl ? (
            <img
              src={localPreview ?? avatarUrl ?? ""}
              alt="Foto de perfil"
              className="h-full w-full object-cover object-center block"
            />
          ) : (
            initials
          )}
        </div>
        <div className="flex flex-col gap-2 flex-1">
          <button
            type="button"
            onClick={() => cameraInputRef.current?.click()}
            disabled={uploadMutation.isPending}
            className="inline-flex items-center justify-center gap-2 px-3 py-2 rounded-md bg-primary text-primary-foreground text-sm font-semibold hover:bg-primary/90 disabled:opacity-60"
          >
            <Camera className="size-4" /> Tirar foto
          </button>
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            disabled={uploadMutation.isPending}
            className="inline-flex items-center justify-center gap-2 px-3 py-2 rounded-md border border-border text-sm font-semibold hover:bg-muted disabled:opacity-60"
          >
            <Upload className="size-4" /> Carregar foto
          </button>
          {uploadMutation.isPending && (
            <p className="text-xs text-muted-foreground">Enviando...</p>
          )}
        </div>
        <input
          ref={cameraInputRef}
          type="file"
          accept="image/*"
          capture="user"
          className="hidden"
          onChange={(e) => {
            handleFile(e.target.files?.[0]);
            e.target.value = "";
          }}
        />
        <input
          ref={fileInputRef}
          type="file"
          accept="image/*"
          className="hidden"
          onChange={(e) => {
            handleFile(e.target.files?.[0]);
            e.target.value = "";
          }}
        />
      </div>

      <form
        onSubmit={(e) => {
          e.preventDefault();
          saveMutation.mutate();
        }}
        className="panel p-5 space-y-4"
      >
        <div>
          <label className="text-xs font-mono uppercase tracking-widest text-muted-foreground">E-mail</label>
          <input
            value={profile?.email ?? ""}
            disabled
            className="mt-1 w-full px-3 py-2 rounded-md bg-muted text-muted-foreground border border-border text-sm"
          />
        </div>

        <div>
          <label className="text-xs font-mono uppercase tracking-widest text-muted-foreground">Nome</label>
          <input
            value={nome}
            onChange={(e) => setNome(e.target.value)}
            maxLength={100}
            required
            className="mt-1 w-full px-3 py-2 rounded-md bg-background border border-border text-sm focus:outline-none focus:ring-2 focus:ring-ring"
          />
        </div>

        <div>
          <label className="text-xs font-mono uppercase tracking-widest text-muted-foreground">Matrícula</label>
          <input
            value={matricula}
            onChange={(e) => setMatricula(e.target.value)}
            maxLength={50}
            required
            className="mt-1 w-full px-3 py-2 rounded-md bg-background border border-border text-sm focus:outline-none focus:ring-2 focus:ring-ring"
          />
        </div>

        <div>
          <label className="text-xs font-mono uppercase tracking-widest text-muted-foreground">Empresa</label>
          <select
            value={companyId}
            onChange={(e) => setCompanyId(e.target.value)}
            className="mt-1 w-full px-3 py-2 rounded-md bg-background border border-border text-sm focus:outline-none focus:ring-2 focus:ring-ring"
          >
            <option value="">— Selecione —</option>
            {companies.map((c) => (
              <option key={c.id} value={c.id}>{c.nome}</option>
            ))}
          </select>
        </div>

        <button
          type="submit"
          disabled={saveMutation.isPending}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-md bg-primary text-primary-foreground text-sm font-semibold hover:bg-primary/90 disabled:opacity-60"
        >
          <Save className="size-4" /> {saveMutation.isPending ? "Salvando..." : "Salvar"}
        </button>
      </form>

      {pendingFile && (
        <AvatarCropper
          file={pendingFile}
          onCancel={() => setPendingFile(null)}
          onConfirm={handleCropConfirm}
          isSaving={uploadMutation.isPending}
        />
      )}

      <PrivacyPortal userId={user.id} />

      <InstallAppSection />
    </div>
  );
}

