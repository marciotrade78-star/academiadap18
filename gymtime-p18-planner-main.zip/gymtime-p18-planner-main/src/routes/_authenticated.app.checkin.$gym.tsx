import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { GYMS, type GymType } from "@/lib/slots";
import { CheckCircle2, XCircle, Loader2, Dumbbell, Waves, ArrowLeft } from "lucide-react";

export const Route = createFileRoute("/_authenticated/app/checkin/$gym")({
  beforeLoad: ({ params }) => {
    if (params.gym !== "musculacao" && params.gym !== "aerobica") throw notFound();
  },
  component: CheckinPage,
});

type Result = { ok: boolean; reason: string; slot?: string };

function CheckinPage() {
  const { gym } = Route.useParams() as { gym: GymType };
  const meta = GYMS.find((g) => g.value === gym)!;
  const Icon = gym === "musculacao" ? Dumbbell : Waves;
  const color = gym === "musculacao" ? "var(--musc)" : "var(--aero)";
  const [loading, setLoading] = useState(true);
  const [result, setResult] = useState<Result | null>(null);

  useEffect(() => {
    (async () => {
      const { data, error } = await supabase.rpc("check_in_booking", { _gym: gym });
      if (error) setResult({ ok: false, reason: "error" });
      else setResult(data as Result);
      setLoading(false);
    })();
  }, [gym]);

  const messages: Record<string, { title: string; desc: string; ok: boolean }> = {
    confirmed: { title: "Presença confirmada!", desc: "Bom treino.", ok: true },
    already: { title: "Já confirmado", desc: "Sua presença já estava registrada.", ok: true },
    no_booking: { title: "Sem reserva hoje", desc: "Você não tem reserva nesta academia para hoje.", ok: false },
    out_of_window: { title: "Fora do horário", desc: "A confirmação só é aceita de 10 min antes até 45 min após o início da sua reserva.", ok: false },
    error: { title: "Erro", desc: "Não foi possível confirmar agora. Tente novamente.", ok: false },
  };

  return (
    <div className="space-y-5">
      <Link to="/app" className="inline-flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground">
        <ArrowLeft className="size-3.5" /> Voltar
      </Link>
      <div className="flex items-center gap-3">
        <div className="size-11 rounded-xl grid place-items-center" style={{ background: `color-mix(in oklch, ${color}, transparent 80%)`, color }}>
          <Icon className="size-5" />
        </div>
        <div>
          <p className="text-xs font-mono uppercase tracking-widest" style={{ color }}>{meta.label}</p>
          <h1 className="text-2xl font-bold tracking-tight">Check-in</h1>
        </div>
      </div>

      <div className="panel p-6 text-center">
        {loading || !result ? (
          <div className="grid place-items-center py-8"><Loader2 className="animate-spin size-6 text-muted-foreground" /></div>
        ) : (
          <>
            {messages[result.reason]?.ok ? (
              <CheckCircle2 className="mx-auto size-14 text-success" />
            ) : (
              <XCircle className="mx-auto size-14 text-destructive" />
            )}
            <h2 className="mt-3 text-xl font-bold">{messages[result.reason]?.title ?? "Resultado"}</h2>
            <p className="mt-1 text-sm text-muted-foreground">{messages[result.reason]?.desc}</p>
            {result.slot && (
              <p className="mt-3 font-mono text-sm">Horário: {result.slot.slice(0, 5)}</p>
            )}
          </>
        )}
      </div>
    </div>
  );
}
