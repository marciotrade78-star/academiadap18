import { createFileRoute, Outlet, redirect, Link, useRouter } from "@tanstack/react-router";
import { supabase } from "@/integrations/supabase/client";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { LogOut, ShieldCheck, Home, Sun, Moon, User as UserIcon } from "lucide-react";
import { useTheme } from "@/hooks/use-theme";
import { InteractiveTourOverlay } from "@/components/InteractiveTour";

export const Route = createFileRoute("/_authenticated")({
  ssr: false,
  beforeLoad: async () => {
    const { data, error } = await supabase.auth.getUser();
    if (error || !data.user) throw redirect({ to: "/auth" });
    return { user: data.user };
  },
  component: AuthedLayout,
});

function AuthedLayout() {
  const { user } = Route.useRouteContext();
  const router = useRouter();
  const queryClient = useQueryClient();
  const { theme, toggleTheme } = useTheme();

  const { data: isAdmin } = useQuery({
    queryKey: ["role", "admin", user.id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("user_roles").select("role").eq("user_id", user.id).eq("role", "admin").maybeSingle();
      if (error) throw error;
      return !!data;
    },
  });

  async function signOut() {
    await queryClient.cancelQueries();
    queryClient.clear();
    await supabase.auth.signOut();
    router.navigate({ to: "/auth", replace: true });
  }

  return (
    <div className="min-h-screen flex flex-col pb-20">
      <header className="sticky top-0 z-30 backdrop-blur-md bg-background/80 border-b border-border">
        <div className="mx-auto max-w-3xl px-4 h-14 flex items-center justify-between gap-3">
          <Link to="/app" className="flex items-center gap-2 font-bold tracking-tight">
            <img src="/logo-p18.png" alt="P-18" className="h-9 w-auto rounded-full bg-background p-1" />
            <span className="text-sm">Academias</span>
          </Link>
          <div className="flex items-center gap-1">
            {isAdmin && (
              <Link to="/app/admin" className="inline-flex items-center gap-1.5 px-2.5 py-1.5 text-xs rounded-md bg-accent text-accent-foreground hover:bg-accent/80">
                <ShieldCheck className="size-3.5" /> Admin
              </Link>
            )}
            <button
              onClick={toggleTheme}
              className="p-2 rounded-md hover:bg-accent"
              aria-label={theme === "dark" ? "Modo claro" : "Modo escuro"}
              title={theme === "dark" ? "Modo claro" : "Modo escuro"}
            >
              {theme === "dark" ? <Sun className="size-4" /> : <Moon className="size-4" />}
            </button>
            <Link to="/app" className="p-2 rounded-md hover:bg-accent" aria-label="Início">
              <Home className="size-4" />
            </Link>
            <Link to="/app/perfil" className="p-2 rounded-md hover:bg-accent" aria-label="Perfil">
              <UserIcon className="size-4" />
            </Link>
            <button onClick={signOut} className="p-2 rounded-md hover:bg-accent" aria-label="Sair">
              <LogOut className="size-4" />
            </button>
          </div>
        </div>
      </header>
      <main className="flex-1 mx-auto w-full max-w-3xl px-4 py-5">
        <Outlet />
      </main>
      <InteractiveTourOverlay />
    </div>
  );
}
