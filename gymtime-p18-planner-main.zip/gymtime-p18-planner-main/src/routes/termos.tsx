import { createFileRoute, Link } from "@tanstack/react-router";
import { CONTROLLER, LAST_UPDATED, TERMS_VERSION } from "@/lib/lgpd";

export const Route = createFileRoute("/termos")({
  head: () => ({
    meta: [
      { title: "Termos de Uso — P-18 Academias" },
      { name: "description", content: "Termos de Uso da plataforma de reservas de academias P-18." },
      { property: "og:title", content: "Termos de Uso — P-18 Academias" },
      { property: "og:url", content: "https://gymtime-p18-planner.lovable.app/termos" },
    ],
    links: [{ rel: "canonical", href: "https://gymtime-p18-planner.lovable.app/termos" }],
  }),
  component: TermsPage,
});

function TermsPage() {
  return (
    <main className="min-h-screen px-5 py-10 max-w-3xl mx-auto">
      <nav className="text-xs text-muted-foreground mb-6">
        <Link to="/" className="hover:text-foreground">← Início</Link>
      </nav>
      <article className="space-y-5 text-sm leading-relaxed">
        <header>
          <h1 className="text-3xl font-bold">Termos de Uso</h1>
          <p className="text-xs text-muted-foreground mt-1">
            Versão {TERMS_VERSION} · Última atualização: {LAST_UPDATED}
          </p>
        </header>

        <p>
          Estes Termos regem o uso da plataforma de reservas de academias operada pela <strong>{CONTROLLER.nome}</strong>.
          Ao criar uma conta você declara ter lido e concordado integralmente com estes Termos e com a{" "}
          <Link to="/privacidade" className="text-primary underline">Política de Privacidade</Link>.
        </p>

        <section>
          <h2 className="text-xl font-semibold">1. Conta</h2>
          <p>Você é responsável pela veracidade dos dados informados e pelo sigilo de sua senha. É vedado compartilhar credenciais.</p>
        </section>

        <section>
          <h2 className="text-xl font-semibold">2. Uso adequado</h2>
          <ul className="list-disc pl-5 space-y-1">
            <li>Reservar somente horários que efetivamente irá utilizar;</li>
            <li>Não tentar burlar limites de capacidade ou acessar dados de terceiros;</li>
            <li>Não enviar conteúdo ilícito, ofensivo ou em violação a direitos.</li>
          </ul>
        </section>

        <section>
          <h2 className="text-xl font-semibold">3. Disponibilidade</h2>
          <p>O serviço é fornecido "como está". Podemos realizar manutenções e alterações sem aviso prévio.</p>
        </section>

        <section>
          <h2 className="text-xl font-semibold">4. Rescisão</h2>
          <p>Você pode encerrar sua conta a qualquer momento pelo portal no seu perfil. Poderemos suspender contas em caso de violação destes Termos.</p>
        </section>

        <section>
          <h2 className="text-xl font-semibold">5. Foro</h2>
          <p>Fica eleito o foro da comarca da sede da controladora para dirimir controvérsias.</p>
        </section>

        <p className="text-xs text-muted-foreground">
          Contato: <a className="text-primary underline" href={`mailto:${CONTROLLER.email}`}>{CONTROLLER.email}</a>
        </p>
      </article>
    </main>
  );
}
