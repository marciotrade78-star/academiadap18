import { createFileRoute, useNavigate, useSearch, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { z } from "zod";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { toast } from "sonner";
import { Waves, Dumbbell, Eye, EyeOff, MailCheck } from "lucide-react";
import { InstallPrompt } from "@/components/InstallPrompt";
import { InstallHelp } from "@/components/InstallHelp";
import { PRIVACY_VERSION, TERMS_VERSION } from "@/lib/lgpd";

const searchSchema = z.object({ mode: z.enum(["signin", "signup"]).optional() });

export const Route = createFileRoute("/auth")({
  validateSearch: searchSchema,
  component: AuthPage,
});

const signupSchema = z.object({
  nome: z.string().trim().min(2, "Informe seu nome").max(120),
  matricula: z.string().trim().min(3, "Matrícula/SISPATE inválida").max(40)
    .regex(/^[A-Za-z0-9.-]+$/, "Use letras, números, '.' ou '-'"),
  company_id: z.string().uuid("Selecione sua empresa"),
  email: z.string().trim().email("E-mail inválido").max(255),
  password: z.string().min(8, "Mínimo 8 caracteres").max(72),
  accept_terms: z.literal("on", { errorMap: () => ({ message: "Você precisa aceitar os Termos e a Política de Privacidade." }) }),
});
const signinSchema = z.object({
  email: z.string().trim().email("E-mail inválido"),
  password: z.string().min(1, "Senha obrigatória"),
});

function AuthPage() {
  const search = useSearch({ from: "/auth" });
  const navigate = useNavigate();
  const initial = search.mode === "signup" ? "signup" : "signin";
  const [mode, setMode] = useState<"signin" | "signup" | "forgot">(initial);
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [showSignupPassword, setShowSignupPassword] = useState(false);
  const [forgotSent, setForgotSent] = useState(false);
  const [rememberMe, setRememberMe] = useState(true);
  const [companies, setCompanies] = useState<{ id: string; nome: string }[]>([]);

  useEffect(() => {
    let active = true;
    (async () => {
      const { data } = await supabase.from("companies").select("id, nome").order("nome");
      if (active && data) setCompanies(data);
    })();
    return () => { active = false; };
  }, []);

  async function handleSignIn(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const parsed = signinSchema.safeParse(Object.fromEntries(fd));
    if (!parsed.success) { toast.error(parsed.error.issues[0].message); return; }
    setLoading(true);
    const { error } = await supabase.auth.signInWithPassword(parsed.data);
    setLoading(false);
    if (error) return toast.error(error.message);
    localStorage.setItem("gymtime-remember-me", rememberMe ? "true" : "false");
    if (!rememberMe) {
      sessionStorage.setItem("gymtime-tab-active", "true");
      const originalSetItem = localStorage.setItem.bind(localStorage);
      localStorage.setItem = function (key: string, value: string) {
        if (typeof key === "string" && key.startsWith("sb-") && key.endsWith("-auth-token")) return;
        return originalSetItem(key, value);
      };
    }
    toast.success("Bem-vindo!");
    navigate({ to: "/app" });
  }

  async function handleSignUp(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const parsed = signupSchema.safeParse(Object.fromEntries(fd));
    if (!parsed.success) { toast.error(parsed.error.issues[0].message); return; }
    setLoading(true);
    const { error } = await supabase.auth.signUp({
      email: parsed.data.email,
      password: parsed.data.password,
      options: {
        emailRedirectTo: `${window.location.origin}/app`,
        data: { nome: parsed.data.nome, matricula: parsed.data.matricula, company_id: parsed.data.company_id },
      },
    });
    setLoading(false);
    if (error) {
      const msg = (error.message || "").toLowerCase();
      if (msg.includes("matricula_duplicada") || msg.includes("profiles_matricula_key"))
        toast.error("Já existe um usuário com esta matrícula/SISPATE.");
      else if (msg.includes("already") || msg.includes("registered") || msg.includes("exists"))
        toast.error("Já existe conta com este e-mail.");
      else if (msg.includes("password") && (msg.includes("weak") || msg.includes("pwned") || msg.includes("compromised")))
        toast.error("Senha muito fraca ou comprometida. Use uma senha mais forte.");
      else if (msg.includes("failed to fetch") || msg.includes("network"))
        toast.error("Falha de conexão. Verifique sua internet e tente novamente.");
      else if (msg.includes("database error"))
        toast.error("Não foi possível concluir o cadastro. Verifique os dados (matrícula/e-mail podem já existir).");
      else toast.error(error.message);
      return;
    }

    // Registra consentimentos (LGPD) e versões aceitas no perfil
    const { data: sess } = await supabase.auth.getSession();
    const uid = sess.session?.user.id;
    if (uid) {
      const now = new Date().toISOString();
      await supabase.from("consents").insert([
        { user_id: uid, tipo: "privacy_policy", version: PRIVACY_VERSION, granted: true, user_agent: navigator.userAgent },
        { user_id: uid, tipo: "terms_of_use", version: TERMS_VERSION, granted: true, user_agent: navigator.userAgent },
      ]);
      await supabase.from("profiles").update({
        privacy_version: PRIVACY_VERSION,
        privacy_accepted_at: now,
        terms_version: TERMS_VERSION,
        terms_accepted_at: now,
      }).eq("id", uid);
    }

    toast.success("Cadastro criado!");
    navigate({ to: "/app" });
  }

  async function handleForgot(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const email = z.string().email().safeParse(fd.get("email")?.toString() ?? "");
    if (!email.success) { toast.error("E-mail inválido"); return; }
    setLoading(true);
    const { error } = await supabase.auth.resetPasswordForEmail(email.data, {
      redirectTo: `${window.location.origin}/reset-password`,
    });
    setLoading(false);
    if (error) return toast.error(error.message);
    toast.success("Verifique seu e-mail cadastrado para redefinir a senha.");
    setForgotSent(true);
  }

  return (
    <main className="min-h-screen flex flex-col">
      <header className="px-6 pt-8 pb-6 text-center">
        <img src="/logo-p18.png" alt="Academia da P-18" className="mx-auto h-32 w-auto rounded-full bg-background p-2 shadow-lg" />
        <div className="mt-2 inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 text-primary text-xs font-mono uppercase tracking-widest">
          <span className="size-1.5 rounded-full bg-primary animate-pulse" /> Plataforma P-18
        </div>
        <h1 className="mt-3 text-2xl font-bold tracking-tight">Academias da P-18</h1>
        <p className="mt-2 text-sm text-muted-foreground max-w-sm mx-auto">
          Reserve seus 45 minutos de musculação e aeróbica.
        </p>
        <div className="mt-5 flex justify-center gap-3 text-xs text-muted-foreground">
          <span className="inline-flex items-center gap-1.5"><Dumbbell className="size-3.5 text-[color:var(--musc)]"/>Musculação</span>
          <span className="inline-flex items-center gap-1.5"><Waves className="size-3.5 text-[color:var(--aero)]"/>Aeróbica</span>
        </div>
      </header>

      <section className="flex-1 px-5 pb-10">
        <div className="mx-auto max-w-md mb-4">
          <InstallPrompt />
        </div>
        <div className="mx-auto max-w-md panel p-6">
          {mode !== "forgot" && (
            <div className="grid grid-cols-2 gap-1 p-1 rounded-lg bg-muted mb-6">
              <button
                type="button"
                onClick={() => setMode("signin")}
                className={`py-2 text-sm rounded-md transition ${mode==="signin" ? "bg-primary text-primary-foreground font-semibold" : "text-muted-foreground"}`}
              >Entrar</button>
              <button
                type="button"
                onClick={() => setMode("signup")}
                className={`py-2 text-sm rounded-md transition ${mode==="signup" ? "bg-primary text-primary-foreground font-semibold" : "text-muted-foreground"}`}
              >Cadastrar</button>
            </div>
          )}

          {mode === "signin" && (
            <form onSubmit={handleSignIn} className="space-y-4">
              <div>
                <Label htmlFor="email">E-mail</Label>
                <Input id="email" name="email" type="email" autoComplete="email" required />
              </div>
              <div>
                <Label htmlFor="password">Senha</Label>
                <div className="relative">
                  <Input id="password" name="password" type={showPassword ? "text" : "password"} autoComplete="current-password" required className="pr-10" />
                  <button type="button" onClick={() => setShowPassword(v => !v)} className="absolute right-2.5 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground" aria-label={showPassword ? "Ocultar senha" : "Mostrar senha"}>
                    {showPassword ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
                  </button>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Checkbox
                  id="remember"
                  checked={rememberMe}
                  onCheckedChange={(v) => setRememberMe(v === true)}
                />
                <Label htmlFor="remember" className="text-xs font-normal cursor-pointer">
                  Manter conectado
                </Label>
              </div>
              <Button type="submit" disabled={loading} className="w-full font-semibold">
                {loading ? "Entrando..." : "Entrar"}
              </Button>
              <p className="text-center">
                <button type="button" onClick={() => { setMode("forgot"); setForgotSent(false); }} className="text-xs text-primary hover:underline">
                  Esqueceu a senha?
                </button>
              </p>
            </form>
          )}

          {mode === "forgot" && forgotSent && (
            <div className="space-y-4 text-center">
              <div className="mx-auto w-12 h-12 rounded-full bg-success/15 grid place-items-center">
                <MailCheck className="size-6 text-success" />
              </div>
              <div>
                <p className="text-sm font-semibold">E-mail enviado com sucesso!</p>
                <p className="text-sm text-muted-foreground mt-1">
                  Verifique seu e-mail cadastrado e clique no link para redefinir sua senha.
                </p>
              </div>
              <Button onClick={() => { setMode("signin"); setForgotSent(false); }} className="w-full font-semibold">
                Voltar para o login
              </Button>
            </div>
          )}

          {mode === "forgot" && !forgotSent && (
            <form onSubmit={handleForgot} className="space-y-4">
              <p className="text-sm text-muted-foreground">Informe seu e-mail para receber o link de recuperação de senha.</p>
              <div>
                <Label htmlFor="forgot-email">E-mail</Label>
                <Input id="forgot-email" name="email" type="email" autoComplete="email" required />
              </div>
              <Button type="submit" disabled={loading} className="w-full font-semibold">
                {loading ? "Enviando..." : "Enviar link de recuperação"}
              </Button>
              <p className="text-center">
                <button type="button" onClick={() => { setMode("signin"); setForgotSent(false); }} className="text-xs text-muted-foreground hover:text-foreground hover:underline">
                  ← Voltar para o login
                </button>
              </p>
            </form>
          )}

          {mode === "signup" && (
            <form onSubmit={handleSignUp} className="space-y-4">
              <div>
                <Label htmlFor="nome">Nome completo</Label>
                <Input id="nome" name="nome" required maxLength={120} />
              </div>
              <div>
                <Label htmlFor="matricula">Matrícula / SISPATE</Label>
                <Input id="matricula" name="matricula" required maxLength={40} placeholder="Ex.: 123456" />
              </div>
              <div>
                <Label htmlFor="company_id">Empresa</Label>
                <select
                  id="company_id"
                  name="company_id"
                  required
                  defaultValue=""
                  className="flex h-9 w-full rounded-md border border-input bg-input px-3 py-1 text-sm shadow-sm focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
                >
                  <option value="" disabled>Selecione sua empresa</option>
                  {companies.map((c) => (
                    <option key={c.id} value={c.id}>{c.nome}</option>
                  ))}
                </select>
                {companies.length === 0 && (
                  <p className="mt-1 text-xs text-muted-foreground">
                    Nenhuma empresa cadastrada. Solicite ao administrador.
                  </p>
                )}
              </div>
              <div>
                <Label htmlFor="email">E-mail</Label>
                <Input id="email" name="email" type="email" autoComplete="email" required />
              </div>
              <div>
                <Label htmlFor="password">Senha (mínimo 8)</Label>
                <div className="relative">
                  <Input id="password" name="password" type={showSignupPassword ? "text" : "password"} autoComplete="new-password" required minLength={8} className="pr-10" />
                  <button type="button" onClick={() => setShowSignupPassword(v => !v)} className="absolute right-2.5 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground" aria-label={showSignupPassword ? "Ocultar senha" : "Mostrar senha"}>
                    {showSignupPassword ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
                  </button>
                </div>
              </div>
              <label className="flex items-start gap-2 text-xs text-muted-foreground">
                <input type="checkbox" name="accept_terms" required className="mt-0.5" />
                <span>
                  Li e concordo com os{" "}
                  <Link to="/termos" target="_blank" className="text-primary underline">Termos de Uso</Link>{" "}
                  e com a{" "}
                  <Link to="/privacidade" target="_blank" className="text-primary underline">Política de Privacidade</Link>{" "}
                  (LGPD).
                </span>
              </label>
              <Button type="submit" disabled={loading} className="w-full font-semibold">
                {loading ? "Criando..." : "Criar conta"}
              </Button>
            </form>
          )}
        </div>
        <div className="mx-auto max-w-md mt-4">
          <InstallHelp variant="button" />
        </div>
        <div className="flex flex-wrap items-center justify-center gap-x-4 gap-y-2 text-xs text-muted-foreground mt-6">
          <Link to="/app" className="hover:text-foreground">Continuar para o app →</Link>
          <Link to="/privacidade" className="hover:text-foreground">Privacidade</Link>
          <Link to="/termos" className="hover:text-foreground">Termos</Link>
        </div>
      </section>
    </main>
  );
}
