import { createFileRoute, Link, notFound, useNavigate } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { generateSlots, GYMS, type GymType } from "@/lib/slots";
import { ArrowLeft, Dumbbell, Waves, Loader2, Check, Lock, X, QrCode, CheckCircle2 } from "lucide-react";
import { toast } from "sonner";
import { useEffect, useState } from "react";
import { CheckinScanner } from "@/components/CheckinScanner";

export const Route = createFileRoute("/_authenticated/app/$gym")({
  beforeLoad: ({ params }) => {
    if (params.gym !== "musculacao" && params.gym !== "aerobica") throw notFound();
  },
  component: GymPage,
});

const slots = generateSlots();

function spDate(d = new Date()) {
  return new Date(d.toLocaleString("en-US", { timeZone: "America/Sao_Paulo" }));
}

function toISODate(d: Date) {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

function GymPage() {
  const { gym } = Route.useParams() as { gym: GymType };
  const { user } = Route.useRouteContext();
  const qc = useQueryClient();
  const navigate = useNavigate();

  const spNow = spDate();
  const rollover = spNow.getHours() > 18 || (spNow.getHours() === 18 && spNow.getMinutes() >= 45);

  const todayObj = spDate();
  const tomorrowObj = spDate();
  tomorrowObj.setDate(tomorrowObj.getDate() + 1);

  const [isTomorrow, setIsTomorrow] = useState(false);

  const bookingDateObj = isTomorrow && rollover ? tomorrowObj : todayObj;
  const date = toISODate(bookingDateObj);
  const dateLabel = bookingDateObj.toLocaleDateString("pt-BR", { day: "2-digit", month: "2-digit", year: "numeric" });

  const meta = GYMS.find((g) => g.value === gym)!;
  const Icon = gym === "musculacao" ? Dumbbell : Waves;
  const color = gym === "musculacao" ? "var(--musc)" : "var(--aero)";
  const [pending, setPending] = useState<string | null>(null);
  const [scannerOpen, setScannerOpen] = useState(false);
  const [nowTick, setNowTick] = useState(() => Date.now());

  useEffect(() => {
    const i = setInterval(() => setNowTick(Date.now()), 30_000);
    return () => clearInterval(i);
  }, []);

  // Realtime: refresh availability when anyone books/cancels in this gym today
  useEffect(() => {
    const channel = supabase
      .channel(`bookings-${gym}-${date}`)
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "bookings", filter: `booking_date=eq.${date}` },
        () => {
          qc.invalidateQueries({ queryKey: ["gym-slot-counts", gym, date] });
          qc.invalidateQueries({ queryKey: ["bookings-today", date] });
        },
      )
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [gym, date, qc]);

  // Current time as "HH:MM:SS" in São Paulo timezone for comparison with slot_start
  const nowHMS = new Date(nowTick).toLocaleTimeString("en-GB", {
    timeZone: "America/Sao_Paulo",
    hour12: false,
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
  });

  const { data: slotCounts = [], isLoading } = useQuery({
    queryKey: ["gym-slot-counts", gym, date],
    queryFn: async () => {
      const { data, error } = await supabase.rpc("bookings_slot_counts", { _date: date, _gym: gym });
      if (error) throw error;
      return (data ?? []) as Array<{ slot_start: string; count: number }>;
    },
  });


  const { data: myToday = [] } = useQuery({
    queryKey: ["my-bookings", user.id, date],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("bookings").select("id, gym, slot_start, checked_in_at")
        .eq("user_id", user.id).eq("booking_date", date);
      if (error) throw error;
      return data;
    },
  });

  const myHere = myToday.find((b) => b.gym === gym);

  const reserve = useMutation({
    mutationFn: async (slot_start: string) => {
      const { error } = await supabase.from("bookings").insert({
        user_id: user.id, gym, booking_date: date, slot_start,
      });
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Horário marcado com sucesso!", {
        description: "Lembre-se de fazer o check-in na porta da academia, no máximo, 10 minutos antes usando seu aplicativo.",
        duration: 6000,
      });
      qc.invalidateQueries({ queryKey: ["gym-slot-counts", gym, date] });
      qc.invalidateQueries({ queryKey: ["my-bookings", user.id, date] });
      qc.invalidateQueries({ queryKey: ["bookings-today", date] });
    },
    onError: (e: { message?: string; code?: string }) => {
      const msg = e?.message || "";
      if (msg.includes("slot_full")) {
        toast.error("Este horário está lotado (6/6).");
      } else if (msg.includes("duplicate") || msg.includes("unique")) {
        if (msg.includes("user_id")) toast.error("Você já tem reserva nesta academia hoje.");
        else toast.error("Você já está neste horário.");
      } else toast.error("Não foi possível reservar.");
      qc.invalidateQueries({ queryKey: ["gym-slot-counts", gym, date] });
    },
    onSettled: () => setPending(null),
  });

  const SLOT_CAPACITY = 6;

  const cancel = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("bookings").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Reserva cancelada.");
      qc.invalidateQueries({ queryKey: ["gym-slot-counts", gym, date] });
      qc.invalidateQueries({ queryKey: ["my-bookings", user.id, date] });
      qc.invalidateQueries({ queryKey: ["bookings-today", date] });
    },
    onError: () => toast.error("Não foi possível cancelar."),
  });

  const countBySlot = new Map<string, number>();
  for (const r of slotCounts) {
    countBySlot.set(r.slot_start, r.count);
  }
  const mySlotHere = myHere?.slot_start ?? null;


  return (
    <div className="space-y-5">
      <div>
        <Link to="/app" className="inline-flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground">
          <ArrowLeft className="size-3.5" /> Voltar
        </Link>
        <div className="mt-3 flex items-center gap-3">
          <div className="size-11 rounded-xl grid place-items-center" style={{background: `color-mix(in oklch, ${color}, transparent 80%)`, color}}>
            <Icon className="size-5" />
          </div>
          <div className="flex-1">
            <p className="text-xs font-mono uppercase tracking-widest" style={{color}}>{meta.label}</p>
            <h1 className="text-2xl font-bold tracking-tight">Horários do dia: {dateLabel}</h1>
          </div>
          <div className="flex flex-col items-end gap-1.5">
            <span className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground">Cap. {SLOT_CAPACITY}/slot</span>
            <div className="flex rounded-lg border overflow-hidden">
              <button
                onClick={() => setIsTomorrow(false)}
                data-tour="day-today"
                className={`px-2.5 py-1 text-[11px] font-semibold transition ${!isTomorrow ? "bg-primary text-primary-foreground" : "bg-card text-muted-foreground hover:text-foreground"}`}
              >
                Hoje
              </button>
              <button
                onClick={() => {
                  if (rollover) {
                    setIsTomorrow(true);
                  } else {
                    toast.error("Os horários de amanhã só ficam disponíveis a partir das 18:45.");
                  }
                }}
                className={`px-2.5 py-1 text-[11px] font-semibold transition ${isTomorrow ? "bg-primary text-primary-foreground" : rollover ? "bg-card text-muted-foreground hover:text-foreground" : "bg-muted text-muted-foreground/50 cursor-not-allowed"}`}
              >
                Amanhã
              </button>
            </div>
          </div>
        </div>
      </div>

      {myHere && (() => {
        const [hh, mm] = myHere.slot_start.split(":").map(Number);
        const endMin = hh * 60 + mm + 45;
        const endHMS = `${String(Math.floor(endMin / 60)).padStart(2, "0")}:${String(endMin % 60).padStart(2, "0")}:00`;
        const windowOver = !isTomorrow && nowHMS >= endHMS;
        // If slot window passed and user never checked in, hide the reservation card entirely (no-show).
        if (windowOver && !myHere.checked_in_at) return null;
        return (
        <div className="panel p-4 space-y-3" style={{borderColor: color}}>
          <div className="flex items-center justify-between gap-3">
            <div>
              <p className="text-xs font-mono uppercase tracking-widest text-muted-foreground">Sua reserva</p>
              <p className="text-lg font-bold mt-0.5">{myHere.slot_start.slice(0,5)}</p>
              {myHere.checked_in_at && (
                <span className="mt-1 inline-flex items-center gap-1 text-xs font-semibold text-success">
                  <CheckCircle2 className="size-3.5" /> Presença confirmada
                </span>
              )}
            </div>
            {!myHere.checked_in_at && (
              <button
                onClick={() => cancel.mutate(myHere.id)}
                disabled={cancel.isPending}
                className="inline-flex items-center gap-1.5 px-3 py-2 rounded-md bg-destructive/15 text-destructive text-sm font-semibold hover:bg-destructive/25 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <X className="size-4" /> Cancelar
              </button>
            )}
          </div>
          {!myHere.checked_in_at && !windowOver && (
            <button
              onClick={() => setScannerOpen(true)}
              className="w-full inline-flex items-center justify-center gap-2 px-3 py-2.5 rounded-md text-sm font-semibold text-white"
              style={{ background: color }}
            >
              <QrCode className="size-4" /> Confirmar presença (escanear QR)
            </button>
          )}
        </div>
        );
      })()}


      {scannerOpen && (
        <CheckinScanner
          gym={gym}
          onClose={() => {
            setScannerOpen(false);
          }}
          onSuccess={(result) => {
            qc.invalidateQueries({ queryKey: ["my-bookings", user.id, date] });
            qc.invalidateQueries({ queryKey: ["gym-slot-counts", gym, date] });
            if (result.ok) {
              setTimeout(() => {
                setScannerOpen(false);
                navigate({ to: "/app" });
              }, 1500);
            }
          }}
        />
      )}

      {isLoading ? (
        <div className="grid place-items-center py-12"><Loader2 className="animate-spin size-5 text-muted-foreground"/></div>
      ) : (() => {
        let firstFreeSlot: string | null = null;
        for (const s of slots) {
          const cnt = countBySlot.get(s.start) ?? 0;
          const mineHere = mySlotHere === s.start;
          const full = cnt >= SLOT_CAPACITY;
          const [sh, sm] = s.start.split(":").map(Number);
          const endHMS = `${String(Math.floor((sh * 60 + sm + 45) / 60)).padStart(2, "0")}:${String((sh * 60 + sm + 45) % 60).padStart(2, "0")}:00`;
          const past = !isTomorrow && endHMS <= nowHMS;
          const blockedByOther = !!myHere && !mineHere;
          if (!mineHere && !full && !blockedByOther && !past) { firstFreeSlot = s.start; break; }
        }
        return (
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
          {slots.map((s) => {
            const count = countBySlot.get(s.start) ?? 0;
            const isMine = mySlotHere === s.start;

            const isFull = count >= SLOT_CAPACITY;
            const isPending = pending === s.start;
            const [sh, sm] = s.start.split(":").map(Number);
            const slotEndMin = sh * 60 + sm + 45;
            const slotEndHMS = `${String(Math.floor(slotEndMin / 60)).padStart(2, "0")}:${String(slotEndMin % 60).padStart(2, "0")}:00`;
            const isPast = !isTomorrow && slotEndHMS <= nowHMS;
            const disabledByOtherGym = !!myHere && !isMine;
            const canReserve = !isMine && !isFull && !disabledByOtherGym && !isPast;
            const pct = Math.min(100, (count / SLOT_CAPACITY) * 100);
            const remaining = SLOT_CAPACITY - count;

            let cardBg = "bg-card";
            let cardBorder = "border-success/30";
            let statusColor = "text-muted-foreground";
            let barColor = color;
            let dotsFill = color;

            if (isPast && !isMine) {
              cardBg = "bg-muted/30";
              cardBorder = "border-border";
              statusColor = "text-muted-foreground";
              barColor = "var(--muted)";
              dotsFill = "var(--muted-foreground)";
            } else if (isMine) {
              cardBg = "bg-success/10";
              cardBorder = "border-success/50";
              statusColor = "text-success";
              barColor = "var(--success)";
              dotsFill = "var(--success)";
            } else if (isFull) {
              cardBg = "bg-destructive/5";
              cardBorder = "border-destructive/30";
              statusColor = "text-destructive";
              barColor = "var(--destructive)";
              dotsFill = "var(--destructive)";
            } else if (count >= 4) {
              cardBg = "bg-warning/10";
              cardBorder = "border-warning/40";
              statusColor = "text-warning";
              barColor = "var(--warning)";
              dotsFill = "var(--warning)";
            }

            return (
              <button
                key={s.start}
                disabled={!canReserve || isPending}
                data-tour={s.start === firstFreeSlot ? "slot-free" : undefined}
                onClick={() => { setPending(s.start); reserve.mutate(s.start); }}
                className={`relative rounded-xl border p-3 text-left transition ${cardBg} ${cardBorder} ${canReserve ? "hover:ring-2 hover:ring-[color:var(--ring)] hover:scale-[1.02]" : isPast && !isMine ? "opacity-50 cursor-not-allowed" : "opacity-80 cursor-not-allowed"}`}
              >
                <div className="flex items-center justify-between gap-2">
                  <div className="font-mono text-sm font-bold">{s.label}</div>
                  {isMine ? (
                    <Check className="size-4 shrink-0" style={{ color: "var(--success)" }} />
                  ) : isPast ? (
                    <Lock className="size-3.5 shrink-0 text-muted-foreground" />
                  ) : isFull ? (
                    <Lock className="size-3.5 shrink-0 text-muted-foreground" />
                  ) : null}
                </div>


                {/* Dots representing each of the 6 slots */}
                <div className="mt-2.5 flex items-center gap-1">
                  {Array.from({ length: SLOT_CAPACITY }).map((_, i) => (
                    <div
                      key={i}
                      className="h-1.5 w-1.5 rounded-full transition-colors"
                      style={{
                        background: i < count ? dotsFill : "var(--muted)",
                        opacity: i < count ? 1 : 0.35,
                      }}
                    />
                  ))}
                </div>

                {/* Progress bar */}
                <div className="mt-2 h-1.5 rounded-full bg-muted overflow-hidden">
                  <div
                    className="h-full rounded-full transition-all"
                    style={{ width: `${pct}%`, background: barColor }}
                  />
                </div>

                <div className={`mt-1.5 font-mono text-[11px] tabular-nums ${statusColor}`}>
                {isPending ? "Reservando…" :
                    isPast ? (isMine && myHere?.checked_in_at ? "Presença confirmada · encerrado" : "Horário encerrado") :
                    isMine ? (myHere?.checked_in_at ? `Presença confirmada · ${remaining} vaga${remaining === 1 ? "" : "s"} disponíve${remaining === 1 ? "l" : "is"}` : `Reserva ativa · ${remaining} vaga${remaining === 1 ? "" : "s"} disponíve${remaining === 1 ? "l" : "is"}`) :
                    isFull ? "Lotado · 0 vagas disponíveis" :
                    `${remaining} vaga${remaining === 1 ? "" : "s"} disponíve${remaining === 1 ? "l" : "is"}`}
                </div>
              </button>
            );
          })}
        </div>
        );
      })()}
    </div>
  );
}
