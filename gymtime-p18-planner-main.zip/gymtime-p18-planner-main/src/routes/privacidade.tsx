import { createFileRoute, Link } from "@tanstack/react-router";
import { CONTROLLER, LAST_UPDATED, PRIVACY_VERSION } from "@/lib/lgpd";

export const Route = createFileRoute("/privacidade")({
  head: () => ({
    meta: [
      { title: "Política de Privacidade — P-18 Academias" },
      { name: "description", content: "Política de Privacidade conforme a LGPD (Lei 13.709/2018) da plataforma de reservas P-18 Academias." },
      { property: "og:title", content: "Política de Privacidade — P-18 Academias" },
      { property: "og:description", content: "Como tratamos seus dados pessoais segundo a LGPD." },
      { property: "og:url", content: "https://gymtime-p18-planner.lovable.app/privacidade" },
    ],
    links: [{ rel: "canonical", href: "https://gymtime-p18-planner.lovable.app/privacidade" }],
  }),
  component: PrivacyPage,
});

function PrivacyPage() {
  return (
    <main className="min-h-screen px-5 py-10 max-w-3xl mx-auto">
      <nav className="text-xs text-muted-foreground mb-6">
        <Link to="/" className="hover:text-foreground">← Início</Link>
      </nav>
      <article className="prose prose-invert max-w-none space-y-5 text-sm leading-relaxed">
        <header>
          <h1 className="text-3xl font-bold">Política de Privacidade</h1>
          <p className="text-xs text-muted-foreground mt-1">
            Versão {PRIVACY_VERSION} · Última atualização: {LAST_UPDATED}
          </p>
        </header>

        <p>
          Esta Política descreve como a <strong>{CONTROLLER.nome}</strong> ("nós"), na qualidade
          de <strong>controladora</strong> dos dados, trata as informações pessoais dos usuários ("você", "titular")
          da plataforma de reservas de academias, em cumprimento à <strong>Lei nº 13.709/2018 — Lei Geral de
          Proteção de Dados Pessoais (LGPD)</strong>.
        </p>

        <section>
          <h2 className="text-xl font-semibold">1. Dados que tratamos</h2>
          <ul className="list-disc pl-5 space-y-1">
            <li><strong>Cadastro:</strong> nome completo, e-mail, matrícula/SISPATE, empresa vinculada e senha (armazenada com hash).</li>
            <li><strong>Perfil:</strong> foto de avatar (opcional).</li>
            <li><strong>Uso:</strong> agendamentos, horários reservados, check-ins realizados.</li>
            <li><strong>Técnicos:</strong> endereço IP, navegador, registros de acesso (logs) e cookies essenciais.</li>
            <li><strong>Comunicação:</strong> feedbacks enviados voluntariamente.</li>
          </ul>
        </section>

        <section>
          <h2 className="text-xl font-semibold">2. Finalidades e bases legais (art. 7º, LGPD)</h2>
          <ul className="list-disc pl-5 space-y-1">
            <li><strong>Execução de contrato</strong> — autenticação, reserva de horários, controle de capacidade e check-in.</li>
            <li><strong>Cumprimento de obrigação legal</strong> — guarda de registros de acesso (Marco Civil, art. 15).</li>
            <li><strong>Legítimo interesse</strong> — segurança, prevenção a fraudes e melhoria do serviço.</li>
            <li><strong>Consentimento</strong> — cookies analíticos e comunicações de marketing (revogáveis a qualquer momento).</li>
          </ul>
        </section>

        <section>
          <h2 className="text-xl font-semibold">3. Compartilhamento</h2>
          <p>Não vendemos seus dados. Compartilhamos apenas com:</p>
          <ul className="list-disc pl-5 space-y-1">
            <li>Provedores de infraestrutura em nuvem (operadores), sob contrato e dever de sigilo.</li>
            <li>Autoridades públicas, quando legalmente exigido.</li>
            <li>Sua empresa vinculada, apenas para fins administrativos do benefício de academia.</li>
          </ul>
        </section>

        <section>
          <h2 className="text-xl font-semibold">4. Retenção</h2>
          <p>
            Mantemos seus dados enquanto sua conta estiver ativa. Após a exclusão, registros de acesso podem
            ser retidos por até 6 meses (Marco Civil) e dados estritamente necessários por prazos legais.
          </p>
        </section>

        <section>
          <h2 className="text-xl font-semibold">5. Direitos do titular (art. 18, LGPD)</h2>
          <p>Você pode, gratuitamente, a qualquer tempo:</p>
          <ul className="list-disc pl-5 space-y-1">
            <li>Confirmar a existência de tratamento e acessar seus dados;</li>
            <li>Corrigir dados incompletos, inexatos ou desatualizados;</li>
            <li>Solicitar a portabilidade (exportação em formato legível);</li>
            <li>Solicitar a eliminação dos dados tratados com base no consentimento;</li>
            <li>Revogar o consentimento;</li>
            <li>Obter informação sobre o compartilhamento.</li>
          </ul>
          <p className="mt-2">
            Use o <Link to="/app/perfil" className="text-primary underline">portal de privacidade no seu perfil</Link> ou
            escreva para <a className="text-primary underline" href={`mailto:${CONTROLLER.email}`}>{CONTROLLER.email}</a>.
          </p>
        </section>

        <section>
          <h2 className="text-xl font-semibold">6. Segurança</h2>
          <p>
            Adotamos medidas técnicas e administrativas adequadas (criptografia em trânsito, controle de acesso por
            perfis, RLS no banco de dados, hashing de senhas) para proteger seus dados contra acessos não autorizados.
          </p>
        </section>

        <section>
          <h2 className="text-xl font-semibold">7. Cookies</h2>
          <p>
            Utilizamos cookies essenciais (sessão e autenticação) e, mediante consentimento, cookies analíticos.
            Você pode rever sua escolha a qualquer momento limpando o armazenamento do site.
          </p>
        </section>

        <section>
          <h2 className="text-xl font-semibold">8. Encarregado (DPO) e contato</h2>
          <p>{CONTROLLER.encarregado}</p>
          <p>E-mail: <a className="text-primary underline" href={`mailto:${CONTROLLER.email}`}>{CONTROLLER.email}</a></p>
        </section>

        <section>
          <h2 className="text-xl font-semibold">9. Alterações</h2>
          <p>
            Esta Política pode ser atualizada. Mudanças relevantes serão comunicadas no app e exigirão novo aceite.
          </p>
        </section>
      </article>
    </main>
  );
}
