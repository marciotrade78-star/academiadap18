import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { todayISO, GYMS, generateSlots } from "@/lib/slots";
import { Dumbbell, Waves, Clock, CheckCircle2, ArrowRight } from "lucide-react";
import { InstallPrompt } from "@/components/InstallPrompt";
import { ShareApp } from "@/components/ShareApp";
import { FeedbackForm } from "@/components/FeedbackForm";
import { ReservationsList } from "@/components/ReservationsList";
import { AppTour } from "@/components/AppTour";

export const Route = createFileRoute("/_authenticated/app/")({
  component: HomePage,
});

const slots = generateSlots();

function HomePage() {
  const { user } = Route.useRouteContext();
  const date = todayISO();

  const { data: myBookings = [] } = useQuery({
    queryKey: ["my-bookings", user.id, date],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("bookings")
        .select("id, gym, slot_start")
        .eq("user_id", user.id)
        .eq("booking_date", date);
      if (error) throw error;
      return data;
    },
  });

  const { data: gymCounts = [] } = useQuery({
    queryKey: ["bookings-today", date],
    queryFn: async () => {
      const { data, error } = await supabase.rpc("bookings_gym_counts", { _date: date });
      if (error) throw error;
      return (data ?? []) as Array<{ gym: string; count: number }>;
    },
  });

  const myByGym = new Map(myBookings.map((b) => [b.gym, b.slot_start]));
  const SLOT_CAPACITY = 6;
  const countByGym = new Map(gymCounts.map((g) => [g.gym, g.count]));
  const occByGym = (g: string) => countByGym.get(g) ?? 0;
  const totalCapacity = slots.length * SLOT_CAPACITY;


  const today = new Date().toLocaleDateString("pt-BR", { weekday: "long", day: "numeric", month: "long" });

  return (
    <div className="space-y-6">
      <section>
        <p className="text-xs font-mono uppercase tracking-widest text-muted-foreground">{today}</p>
        <h1 className="mt-1 text-2xl font-bold tracking-tight">Reserve seu treino</h1>
        <p className="text-sm text-muted-foreground mt-1">
          Slots de 45 min. Você pode reservar <span className="text-foreground font-semibold">um por academia</span> ao dia.
        </p>
      </section>

      <section className="grid gap-4 sm:grid-cols-2">
        {GYMS.map((g) => {
          const mine = myByGym.get(g.value);
          const occupied = occByGym(g.value);
          const Icon = g.value === "musculacao" ? Dumbbell : Waves;
          const color = g.value === "musculacao" ? "var(--musc)" : "var(--aero)";
          return (
            <Link
              key={g.value}
              to="/app/$gym"
              params={{ gym: g.value }}
              data-tour={g.value === "musculacao" ? "gym-musculacao" : undefined}
              className="panel relative overflow-hidden group p-5 hover:border-[color:var(--ring)] transition"
            >
              <div className="absolute inset-0 grid-stripes opacity-30 pointer-events-none" style={{color}}/>
              <div className="relative flex items-start justify-between">
                <div>
                  <div className="inline-flex items-center gap-2 text-xs font-mono uppercase tracking-widest" style={{color}}>
                    <Icon className="size-4" /> {g.label}
                  </div>
                  <h2 className="mt-2 text-xl font-bold">Academia de {g.label}</h2>
                  {mine ? (
                    <div className="mt-3 inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-success/15 text-success text-xs font-semibold">
                      <CheckCircle2 className="size-3.5" /> Você: {mine.slice(0, 5)}
                    </div>
                  ) : (
                    <div className="mt-3 inline-flex items-center gap-1.5 text-xs text-muted-foreground">
                      <Clock className="size-3.5" /> Sem reserva ainda
                    </div>
                  )}
                </div>
                <ArrowRight className="size-5 text-muted-foreground group-hover:text-foreground group-hover:translate-x-0.5 transition" />
              </div>
              <div className="relative mt-5 flex items-end justify-between gap-3">
                <div className="font-mono text-xs">
                  <span className="text-foreground font-semibold">{totalCapacity - occupied}</span>
                  <span className="text-muted-foreground"> de {totalCapacity} vagas disponíveis</span>
                  {occupied > 0 && (
                    <span className="block text-[10px] text-muted-foreground mt-0.5">{occupied} já reservada{occupied === 1 ? "" : "s"}</span>
                  )}
                </div>
                <div className="h-1.5 w-24 rounded-full bg-muted overflow-hidden shrink-0">
                  <div className="h-full rounded-full" style={{width: `${(occupied/totalCapacity)*100}%`, background: color}} />
                </div>
              </div>
            </Link>
          );
        })}
      </section>

      <ReservationsList />

      <AppTour />

      <InstallPrompt />

      <ShareApp />

      <FeedbackForm />




      <section className="panel p-4 text-xs text-muted-foreground">
        <p className="font-mono uppercase tracking-widest mb-2 text-foreground">Regras</p>
        <ul className="space-y-1 list-disc list-inside">
          <li>Academia aberta 24 horas por dia.</li>
          <li>Cada slot tem 45 minutos.</li>
          <li>1 reserva por academia, por usuário, por dia.</li>
          <li>Reservas valem apenas para o dia corrente.</li>
        </ul>
      </section>
    </div>
  );
}
