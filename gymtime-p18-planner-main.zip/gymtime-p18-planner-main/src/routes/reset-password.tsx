import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useState, useEffect } from "react";
import { z } from "zod";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { Eye, EyeOff } from "lucide-react";

export const Route = createFileRoute("/reset-password")({
  component: ResetPasswordPage,
});

function ResetPasswordPage() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [isRecovery, setIsRecovery] = useState(false);

  useEffect(() => {
    // Supabase puts recovery info in the URL hash
    const hash = window.location.hash;
    if (hash.includes("type=recovery") || hash.includes("access_token")) {
      setIsRecovery(true);
    }
  }, []);

  async function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const password = fd.get("password")?.toString() ?? "";
    const confirm = fd.get("confirm")?.toString() ?? "";

    const parsed = z.string().min(8, "Mínimo 8 caracteres").max(72).safeParse(password);
    if (!parsed.success) { toast.error(parsed.error.issues[0].message); return; }
    if (password !== confirm) { toast.error("As senhas não coincidem."); return; }

    setLoading(true);
    const { error } = await supabase.auth.updateUser({ password });
    setLoading(false);
    if (error) return toast.error(error.message);
    toast.success("Senha atualizada com sucesso!");
    navigate({ to: "/auth" });
  }

  return (
    <main className="min-h-screen flex flex-col items-center justify-center px-5">
      <div className="mx-auto max-w-md w-full panel p-6">
        <h1 className="text-xl font-bold tracking-tight">Redefinir senha</h1>
        {!isRecovery ? (
          <div className="mt-4 space-y-4">
            <p className="text-sm text-muted-foreground">
              Este link parece inválido ou expirado. Solicite um novo link de recuperação.
            </p>
            <Button asChild className="w-full font-semibold">
              <Link to="/auth">Voltar para o login</Link>
            </Button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="mt-4 space-y-4">
            <div>
              <Label htmlFor="password">Nova senha</Label>
              <div className="relative">
                <Input id="password" name="password" type={showPassword ? "text" : "password"} autoComplete="new-password" required minLength={8} className="pr-10" />
                <button type="button" onClick={() => setShowPassword(v => !v)} className="absolute right-2.5 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground" aria-label={showPassword ? "Ocultar senha" : "Mostrar senha"}>
                  {showPassword ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
                </button>
              </div>
            </div>
            <div>
              <Label htmlFor="confirm">Confirmar nova senha</Label>
              <Input id="confirm" name="confirm" type={showPassword ? "text" : "password"} autoComplete="new-password" required minLength={8} />
            </div>
            <Button type="submit" disabled={loading} className="w-full font-semibold">
              {loading ? "Atualizando..." : "Atualizar senha"}
            </Button>
            <p className="text-center text-xs text-muted-foreground">
              <Link to="/auth" className="hover:text-foreground">← Voltar para o login</Link>
            </p>
          </form>
        )}
      </div>
    </main>
  );
}
