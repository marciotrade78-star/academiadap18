// Versões dos documentos legais. Incremente quando alterar o texto
// para que usuários antigos sejam solicitados a reaceitar.
export const PRIVACY_VERSION = "1.0.0";
export const TERMS_VERSION = "1.0.0";

// Dados do controlador — atualize com os dados oficiais da sua organização.
export const CONTROLLER = {
  nome: "P-18 Academias",
  email: "privacidade@p-18.com.br",
  encarregado: "Encarregado de Dados (DPO) — privacidade@p-18.com.br",
};

export const LAST_UPDATED = "21 de junho de 2026";
