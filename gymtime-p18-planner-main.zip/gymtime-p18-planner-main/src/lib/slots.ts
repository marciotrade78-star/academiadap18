// Slots de 45 min cobrindo 24h (00:00 – 24:00).
export const DAY_START_MIN = 0;
export const DAY_END_MIN = 24 * 60;
export const SLOT_MIN = 45;

export interface Slot {
  start: string; // "HH:MM:SS" para casar com type TIME do Postgres
  end: string;   // "HH:MM"
  label: string; // "04:00 – 04:45"
}

function fmt(min: number, withSeconds = false): string {
  const h = Math.floor(min / 60).toString().padStart(2, "0");
  const m = (min % 60).toString().padStart(2, "0");
  return withSeconds ? `${h}:${m}:00` : `${h}:${m}`;
}

export function generateSlots(): Slot[] {
  const out: Slot[] = [];
  for (let s = DAY_START_MIN; s + SLOT_MIN <= DAY_END_MIN; s += SLOT_MIN) {
    out.push({
      start: fmt(s, true),
      end: fmt(s + SLOT_MIN),
      label: `${fmt(s)} – ${fmt(s + SLOT_MIN)}`,
    });
  }
  return out;
}

export function todayISO(): string {
  const d = new Date();
  const y = d.getFullYear();
  const m = (d.getMonth() + 1).toString().padStart(2, "0");
  const day = d.getDate().toString().padStart(2, "0");
  return `${y}-${m}-${day}`;
}

export const GYMS = [
  { value: "musculacao" as const, label: "Musculação", short: "Musc.", token: "musc" },
  { value: "aerobica" as const, label: "Aeróbica", short: "Aero.", token: "aero" },
];
export type GymType = "musculacao" | "aerobica";
