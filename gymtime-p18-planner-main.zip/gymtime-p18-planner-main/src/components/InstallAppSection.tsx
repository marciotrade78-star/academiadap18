import { Download, Share, PlusSquare, Globe, CheckCircle2, Smartphone, MoreVertical, Menu, PackagePlus } from "lucide-react";
import { usePWAInstall } from "@/hooks/use-pwa-install";

export function InstallAppSection() {
  const { canInstall, isInstalled, isIOS, isAndroid, promptInstall } = usePWAInstall();

  if (isInstalled) {
    return (
      <div className="panel p-5 flex items-center gap-3">
        <CheckCircle2 className="size-5 text-green-500" />
        <div>
          <p className="text-sm font-semibold">App instalado</p>
          <p className="text-xs text-muted-foreground">O P-18 Gym já está na tela inicial do seu dispositivo.</p>
        </div>
      </div>
    );
  }

  if (!canInstall) return null;

  return (
    <div className="panel p-5 space-y-4">
      <div className="flex items-center gap-2">
        <Download className="size-5 text-primary" />
        <h2 className="text-sm font-semibold">Instalar aplicativo</h2>
      </div>

      {isIOS ? (
        <IOSInstallSteps />
      ) : isAndroid ? (
        <AndroidInstallSteps promptInstall={promptInstall} />
      ) : (
        <>
          <p className="text-xs text-muted-foreground">
            Instale o P-18 Gym na tela inicial do seu celular para acesso rápido, mesmo offline.
          </p>
          <button
            type="button"
            onClick={promptInstall}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-md bg-primary text-primary-foreground text-sm font-semibold hover:bg-primary/90"
          >
            <Download className="size-4" /> Instalar na tela inicial
          </button>
        </>
      )}
    </div>
  );
}

function IOSInstallSteps() {
  return (
    <div className="space-y-4">
      <p className="text-xs text-muted-foreground">
        No iPhone/iPad, siga os passos abaixo para adicionar o app à sua tela inicial pelo Safari:
      </p>

      <ol className="space-y-3">
        <li className="flex items-start gap-3 rounded-lg bg-muted/50 p-3">
          <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary text-[10px] font-bold text-primary-foreground">
            1
          </div>
          <div className="space-y-1">
            <p className="text-xs font-medium">Abra este site no Safari</p>
            <p className="text-[11px] text-muted-foreground">
              Certifique-se de estar usando o navegador Safari nativo do iOS.
            </p>
            <div className="flex items-center gap-1.5 pt-1">
              <Globe className="size-3.5 text-muted-foreground" />
              <span className="text-[10px] text-muted-foreground font-medium">Safari</span>
            </div>
          </div>
        </li>

        <li className="flex items-start gap-3 rounded-lg bg-muted/50 p-3">
          <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary text-[10px] font-bold text-primary-foreground">
            2
          </div>
          <div className="space-y-1">
            <p className="text-xs font-medium">Toque no botão Compartilhar</p>
            <p className="text-[11px] text-muted-foreground">
              Toque no ícone de compartilhamento na barra inferior do Safari.
            </p>
            <div className="flex items-center gap-1.5 pt-1">
              <Share className="size-3.5 text-blue-500" />
              <span className="text-[10px] text-muted-foreground font-medium">Compartilhar</span>
            </div>
          </div>
        </li>

        <li className="flex items-start gap-3 rounded-lg bg-muted/50 p-3">
          <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary text-[10px] font-bold text-primary-foreground">
            3
          </div>
          <div className="space-y-1">
            <p className="text-xs font-medium">Toque em "Adicionar à Tela de Início"</p>
            <p className="text-[11px] text-muted-foreground">
              Deslize para baixo se necessário e toque na opção com o ícone do app.
            </p>
            <div className="flex items-center gap-1.5 pt-1">
              <PlusSquare className="size-3.5 text-green-500" />
              <span className="text-[10px] text-muted-foreground font-medium">Adicionar à Tela de Início</span>
            </div>
          </div>
        </li>

        <li className="flex items-start gap-3 rounded-lg bg-muted/50 p-3">
          <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary text-[10px] font-bold text-primary-foreground">
            4
          </div>
          <div className="space-y-1">
            <p className="text-xs font-medium">Confirme em "Adicionar"</p>
            <p className="text-[11px] text-muted-foreground">
              O ícone do P-18 Gym aparecerá na sua tela inicial, pronto para usar!
            </p>
            <div className="flex items-center gap-1.5 pt-1">
              <Smartphone className="size-3.5 text-muted-foreground" />
              <span className="text-[10px] text-muted-foreground font-medium">Pronto!</span>
            </div>
          </div>
        </li>
      </ol>

      <div className="rounded-lg bg-amber-500/10 border border-amber-500/20 p-3">
        <p className="text-[11px] text-amber-400 leading-relaxed">
          <strong>Dica:</strong> Se você estiver usando Chrome ou outro navegador no iPhone, 
          abra este link no Safari primeiro para poder instalar o app.
        </p>
      </div>
    </div>
  );
}

function AndroidInstallSteps({ promptInstall }: { promptInstall: () => void }) {
  return (
    <div className="space-y-4">
      <p className="text-xs text-muted-foreground">
        No Android, siga os passos abaixo para instalar o app na tela inicial:
      </p>

      <ol className="space-y-3">
        <li className="flex items-start gap-3 rounded-lg bg-muted/50 p-3">
          <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary text-[10px] font-bold text-primary-foreground">
            1
          </div>
          <div className="space-y-1">
            <p className="text-xs font-medium">Abra este site no Chrome</p>
            <p className="text-[11px] text-muted-foreground">
              Certifique-se de estar usando o navegador Chrome ou Edge no Android.
            </p>
            <div className="flex items-center gap-1.5 pt-1">
              <Globe className="size-3.5 text-muted-foreground" />
              <span className="text-[10px] text-muted-foreground font-medium">Chrome / Edge</span>
            </div>
          </div>
        </li>

        <li className="flex items-start gap-3 rounded-lg bg-muted/50 p-3">
          <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary text-[10px] font-bold text-primary-foreground">
            2
          </div>
          <div className="space-y-1">
            <p className="text-xs font-medium">Toque no menu do navegador</p>
            <p className="text-[11px] text-muted-foreground">
              Toque nos três pontinhos (⋮) no canto superior direito da tela.
            </p>
            <div className="flex items-center gap-1.5 pt-1">
              <MoreVertical className="size-3.5 text-blue-500" />
              <span className="text-[10px] text-muted-foreground font-medium">Menu</span>
            </div>
          </div>
        </li>

        <li className="flex items-start gap-3 rounded-lg bg-muted/50 p-3">
          <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary text-[10px] font-bold text-primary-foreground">
            3
          </div>
          <div className="space-y-1">
            <p className="text-xs font-medium">Toque em "Adicionar à tela inicial"</p>
            <p className="text-[11px] text-muted-foreground">
              Procure a opção "Adicionar à tela inicial" ou "Instalar app" no menu.
            </p>
            <div className="flex items-center gap-1.5 pt-1">
              <PackagePlus className="size-3.5 text-green-500" />
              <span className="text-[10px] text-muted-foreground font-medium">Adicionar à tela inicial</span>
            </div>
          </div>
        </li>

        <li className="flex items-start gap-3 rounded-lg bg-muted/50 p-3">
          <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary text-[10px] font-bold text-primary-foreground">
            4
          </div>
          <div className="space-y-1">
            <p className="text-xs font-medium">Confirme a instalação</p>
            <p className="text-[11px] text-muted-foreground">
              Toque em "Adicionar" ou "Instalar". O ícone do P-18 Gym aparecerá na sua tela inicial!
            </p>
            <div className="flex items-center gap-1.5 pt-1">
              <Smartphone className="size-3.5 text-muted-foreground" />
              <span className="text-[10px] text-muted-foreground font-medium">Pronto!</span>
            </div>
          </div>
        </li>
      </ol>

      <div className="rounded-lg bg-amber-500/10 border border-amber-500/20 p-3">
        <p className="text-[11px] text-amber-400 leading-relaxed">
          <strong>Dica:</strong> Se o navegador mostrar um banner de instalação no rodapé da tela, 
          você pode tocar diretamente nele para instalar mais rápido.
        </p>
      </div>

      <button
        type="button"
        onClick={promptInstall}
        className="w-full inline-flex items-center justify-center gap-2 px-4 py-2 rounded-md bg-primary text-primary-foreground text-sm font-semibold hover:bg-primary/90"
      >
        <Download className="size-4" /> Tentar instalar automaticamente
      </button>
    </div>
  );
}
