import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { signBookingAvatars } from "@/lib/avatars.functions";
import { GYMS, generateSlots } from "@/lib/slots";
import { Dumbbell, Waves, Users, Filter, CalendarDays, Info, Printer } from "lucide-react";
import { useEffect, useState } from "react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Dialog, DialogContent } from "@/components/ui/dialog";

function useIsAdmin() {
  return useQuery({
    queryKey: ["is-admin"],
    queryFn: async () => {
      const { data: userData, error: userError } = await supabase.auth.getUser();
      if (userError || !userData.user) return false;
      const { data } = await supabase
        .from("user_roles")
        .select("role")
        .eq("user_id", userData.user.id)
        .eq("role", "admin")
        .maybeSingle();
      return !!data;
    },
  });
}


interface Row {
  id: string;
  gym: "musculacao" | "aerobica";
  slot_start: string;
  user_id: string;
}

function spDate(d = new Date()) {
  return new Date(d.toLocaleString("en-US", { timeZone: "America/Sao_Paulo" }));
}

function toISODate(d: Date) {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

export function ReservationsList() {
  const spNow = spDate();
  const rollover = spNow.getHours() > 18 || (spNow.getHours() === 18 && spNow.getMinutes() >= 45);

  const todayObj = spDate();
  const tomorrowObj = spDate();
  tomorrowObj.setDate(tomorrowObj.getDate() + 1);

  const [isTomorrow, setIsTomorrow] = useState(false);

  const bookingDateObj = isTomorrow && rollover ? tomorrowObj : todayObj;
  const date = toISODate(bookingDateObj);
  const dateLabel = bookingDateObj.toLocaleDateString("pt-BR", { day: "2-digit", month: "2-digit", year: "numeric" });

  const queryClient = useQueryClient();

  const { data, isLoading } = useQuery({
    queryKey: ["all-bookings-today", date],
    refetchInterval: 15000,
    refetchOnWindowFocus: true,
    queryFn: async () => {
      const { data: listing, error } = await supabase.rpc("public_bookings_listing", { _date: date });
      if (error) throw error;

      const rows: Row[] = (listing ?? []).map((r: { id: string; gym: "musculacao" | "aerobica"; slot_start: string; user_id: string }) => ({
        id: r.id, gym: r.gym, slot_start: r.slot_start, user_id: r.user_id,
      }));

      const profilesMap = new Map<string, { nome: string; company_id: string | null; avatar_url: string | null }>();
      const companyMap = new Map<string, string>();
      const avatarPaths: string[] = [];
      for (const r of (listing ?? []) as Array<{ user_id: string; nome: string | null; avatar_url: string | null; company_id: string | null; company_nome: string | null }>) {
        if (!profilesMap.has(r.user_id)) {
          profilesMap.set(r.user_id, { nome: r.nome ?? "", company_id: r.company_id, avatar_url: r.avatar_url });
          if (r.avatar_url) avatarPaths.push(r.avatar_url);
        }
        if (r.company_id && r.company_nome && !companyMap.has(r.company_id)) {
          companyMap.set(r.company_id, r.company_nome);
        }
      }

      const avatarMap = new Map<string, string>();
      if (avatarPaths.length) {
        try {
          const { urls } = await signBookingAvatars({ data: { paths: avatarPaths } });
          for (const [path, url] of Object.entries(urls)) avatarMap.set(path, url);
        } catch (e) {
          console.error("Failed to sign avatar urls", e);
        }
      }

      return { bookings: rows, profilesMap, companyMap, avatarMap };
    },

  });

  useEffect(() => {
    const channel = supabase
      .channel("bookings-today")
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "bookings", filter: `booking_date=eq.${date}` },
        () => {
          queryClient.invalidateQueries({ queryKey: ["all-bookings-today", date] });
          queryClient.invalidateQueries({ queryKey: ["bookings-count", date] });
          queryClient.invalidateQueries({ queryKey: ["my-bookings", date] });
        }
      )
      .subscribe();
    return () => {
      supabase.removeChannel(channel);
    };
  }, [date, queryClient]);

  const rows = data?.bookings ?? [];
  const profilesMap = data?.profilesMap ?? new Map();
  const companyMap = data?.companyMap ?? new Map();
  const avatarMap = data?.avatarMap ?? new Map<string, string>();

  const allSlots = generateSlots();
  const [slotFilter, setSlotFilter] = useState<Record<"musculacao" | "aerobica", string>>({
    musculacao: "all",
    aerobica: "all",
  });

  const dayLabel = isTomorrow ? "amanhã" : "hoje";

  const { data: isAdmin } = useIsAdmin();
  const [expandedAvatar, setExpandedAvatar] = useState<{ url: string; nome: string } | null>(null);

  return (
    <section className="panel p-4 overflow-hidden">
      <div className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-2 mb-3">
        <div className="flex min-w-0 items-center gap-2">
          <Users className="size-4 shrink-0 text-muted-foreground" />
          <p className="truncate font-mono uppercase tracking-widest text-xs text-foreground">
            Reservas de {dayLabel} · {dateLabel}
          </p>
        </div>
        <div className="inline-flex items-center gap-1 shrink-0">
          <CalendarDays className="size-3 text-muted-foreground" />
          <div className="inline-flex rounded border border-border overflow-hidden">
            <button
              onClick={() => setIsTomorrow(false)}
              className={`px-2 py-0.5 text-[10px] font-mono uppercase tracking-wider ${
                !isTomorrow ? "bg-muted text-foreground" : "bg-background text-muted-foreground"
              }`}
            >
              Hoje
            </button>
            <button
              onClick={() => setIsTomorrow(true)}
              className={`px-2 py-0.5 text-[10px] font-mono uppercase tracking-wider border-l border-border ${
                isTomorrow ? "bg-muted text-foreground" : "bg-background text-muted-foreground"
              }`}
            >
              Amanhã
            </button>
          </div>
        </div>
      </div>

      {isTomorrow && !rollover ? (
        <div className="flex flex-col items-center justify-center gap-4 py-10 px-6 rounded-xl border-2 border-dashed border-muted-foreground/30 bg-muted/20 text-center">
          <Info className="h-10 w-10 text-muted-foreground opacity-60" />
          <div>
            <p className="text-lg font-semibold text-foreground mb-1">
              Ainda não é possível visualizar os agendamentos de amanhã
            </p>
            <p className="text-sm text-muted-foreground">
              A lista pública de reservas para o dia seguinte só será liberada a partir das <strong className="text-foreground">18:45</strong> do dia corrente.
            </p>
          </div>
        </div>
      ) : isLoading ? (
        <p className="text-xs text-muted-foreground">Carregando...</p>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2">
          {GYMS.map((g) => {
            const Icon = g.value === "musculacao" ? Dumbbell : Waves;
            const color = g.value === "musculacao" ? "var(--musc)" : "var(--aero)";
            const gymRows = rows.filter((r) => r.gym === g.value);
            const selected = slotFilter[g.value];
            const list = selected === "all" ? gymRows : gymRows.filter((r) => r.slot_start.slice(0, 5) === selected);
            const slotsWithBookings = new Set(gymRows.map((r) => r.slot_start.slice(0, 5)));
            return (
              <div key={g.value} className="space-y-2 min-w-0">
                <div className="grid grid-cols-[minmax(0,1fr)_auto] items-center gap-2">
                  <div
                    className="inline-flex min-w-0 items-center gap-1.5 text-[11px] font-mono uppercase tracking-widest"
                    style={{ color }}
                  >
                    <Icon className="size-3.5 shrink-0" /> {g.label} · {list.length}
                  </div>
                  <div className="inline-flex items-center gap-1 text-[11px] shrink-0">
                    {isAdmin && (
                      <button
                        type="button"
                        onClick={() => {
                          const sorted = [...gymRows].sort((a, b) => a.slot_start.localeCompare(b.slot_start));
                          const rowsHtml = sorted.map((r) => {
                            const p = profilesMap.get(r.user_id);
                            const companyName = p?.company_id ? (companyMap.get(p.company_id) ?? "—") : "—";
                            const nome = (p?.nome ?? "—").replace(/</g, "&lt;");
                            const comp = companyName.replace(/</g, "&lt;");
                            return `<tr><td>${r.slot_start.slice(0,5)}</td><td>${nome}</td><td>${comp}</td></tr>`;
                          }).join("");
                          const html = `<!doctype html><html><head><meta charset="utf-8"><title>Reservas ${g.label} - ${dateLabel}</title>
<style>
  body{font-family:Arial,sans-serif;padding:24px;color:#000}
  h1{font-size:18px;margin:0 0 4px}
  h2{font-size:13px;margin:0 0 16px;color:#444;font-weight:normal}
  table{width:100%;border-collapse:collapse;font-size:12px}
  th,td{border:1px solid #999;padding:6px 8px;text-align:left}
  th{background:#eee}
  tr:nth-child(even) td{background:#f7f7f7}
  @media print{button{display:none}}
</style></head><body>
<h1>Reservas — ${g.label}</h1>
<h2>${dateLabel} · Total: ${sorted.length}</h2>
<table><thead><tr><th style="width:80px">Horário</th><th>Nome</th><th>Empresa</th></tr></thead>
<tbody>${rowsHtml || '<tr><td colspan="3" style="text-align:center">Nenhuma reserva</td></tr>'}</tbody></table>
<script>window.onload=()=>{window.print()}</script>
</body></html>`;
                          const w = window.open("", "_blank", "width=800,height=600");
                          if (w) { w.document.write(html); w.document.close(); }
                        }}
                        className="inline-flex items-center gap-1 border border-border rounded px-1.5 py-0.5 font-mono text-[11px] hover:bg-muted"
                        title={`Imprimir reservas de ${g.label}`}
                        aria-label={`Imprimir reservas de ${g.label}`}
                      >
                        <Printer className="size-3" /> Imprimir
                      </button>
                    )}
                    <Filter className="size-3 text-muted-foreground shrink-0" />
                    <select
                      value={selected}
                      onChange={(e) =>
                        setSlotFilter((s) => ({ ...s, [g.value]: e.target.value }))
                      }
                      className="bg-background border border-border rounded px-1.5 py-0.5 font-mono text-[11px] focus:outline-none focus:ring-1 focus:ring-ring max-w-[120px]"
                    >
                      <option value="all">Todos horários</option>
                      {allSlots.map((s) => {
                        const hm = s.start.slice(0, 5);
                        const has = slotsWithBookings.has(hm);
                        return (
                          <option key={hm} value={hm}>
                            {hm}{has ? ` (${gymRows.filter((r) => r.slot_start.slice(0,5) === hm).length})` : ""}
                          </option>
                        );
                      })}
                    </select>
                  </div>
                </div>
                {list.length === 0 ? (
                  <p className="text-xs text-muted-foreground">
                    {selected === "all" ? "Nenhuma reserva ainda." : "Nenhuma reserva neste horário."}
                  </p>
                ) : (
                  <ul className="divide-y divide-border rounded-md border border-border overflow-hidden max-h-[480px] overflow-y-auto">
                    {list.map((r) => {
                      const p = profilesMap.get(r.user_id);
                      const companyName = p?.company_id ? (companyMap.get(p.company_id) ?? "—") : "—";
                      const avatar = p?.avatar_url ? avatarMap.get(p.avatar_url) : null;
                      const initial = (p?.nome ?? "?").trim().charAt(0).toUpperCase();
                      return (
                        <li
                          key={r.id}
                          className="flex items-center gap-2 px-3 py-2 text-sm"
                        >
                          <button
                            type="button"
                            onClick={() => avatar && setExpandedAvatar({ url: avatar, nome: p?.nome ?? "" })}
                            className="size-8 rounded-full bg-muted border border-border overflow-hidden flex items-center justify-center text-xs font-bold text-muted-foreground shrink-0 disabled:opacity-60 disabled:cursor-default"
                            disabled={!avatar}
                            aria-label={avatar ? `Ampliar foto de ${p?.nome ?? ""}` : "Sem foto"}
                          >
                            {avatar ? (
                              <img
                                src={avatar}
                                alt={p?.nome ?? ""}
                                className="h-full w-full object-cover object-center block"
                              />
                            ) : (
                              initial
                            )}
                          </button>
                          <div className="min-w-0 flex-1">
                            <p className="truncate font-medium">{p?.nome ?? "—"}</p>
                            <p className="text-[10px] font-mono text-muted-foreground truncate">
                              {companyName}
                            </p>
                          </div>
                          <span
                            className="font-mono text-xs tabular-nums shrink-0"
                            style={{ color }}
                          >
                            {r.slot_start.slice(0, 5)}
                          </span>
                        </li>
                      );
                    })}
                  </ul>
                )}
              </div>
            );
          })}
        </div>
      )}

      <Dialog open={!!expandedAvatar} onOpenChange={() => setExpandedAvatar(null)}>
        <DialogContent className="p-0 border-0 bg-transparent shadow-none max-w-[320px]">
          {expandedAvatar && (
            <img
              src={expandedAvatar.url}
              alt={expandedAvatar.nome}
              className="w-full h-auto rounded-xl border border-border shadow-2xl"
            />
          )}
        </DialogContent>
      </Dialog>
    </section>
  );
}
