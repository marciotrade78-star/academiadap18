import { useEffect, useRef, useState } from "react";
import { X, ArrowRight, Sparkles, MousePointerClick } from "lucide-react";

type Step = {
  target?: string;
  title: string;
  body: string;
  hint?: string;
  advance: "click" | "manual";
};

const STEPS: Step[] = [
  {
    title: "Bora fazer juntos? 👇",
    body:
      "Vou te guiar para fazer sua primeira reserva agora mesmo — siga o brilho na tela. A reserva é real, e você pode encerrar quando quiser.",
    advance: "manual",
  },
  {
    target: '[data-tour="gym-musculacao"]',
    title: "1. Escolha a academia",
    body: "Toque no cartão de Musculação destacado para abrir os horários.",
    advance: "click",
  },
  {
    target: '[data-tour="day-today"]',
    title: "2. Confirme o dia",
    body:
      "Por padrão você reserva para Hoje. Toque em “Hoje” para confirmar (Amanhã só libera depois das 18:45).",
    advance: "click",
  },
  {
    target: '[data-tour="slot-free"]',
    title: "3. Escolha um horário livre",
    body: "Toque em qualquer horário disponível em destaque para reservar de verdade.",
    hint:
      "Verde = livre · Amarelo = quase lotado · Vermelho = lotado · Cinza = encerrado.",
    advance: "click",
  },
  {
    title: "Pronto! 🎉 Reserva feita.",
    body:
      "Sua reserva foi criada de verdade. Quando chegar na academia, abra o app e toque em “Confirmar presença” para escanear o QR Code da porta (até 10 min antes).",
    advance: "manual",
  },
];

// --- tiny external store ---
const listeners = new Set<() => void>();
let state = { active: false, step: 0 };
function emit() {
  listeners.forEach((l) => l());
}
export function startInteractiveTour() {
  state = { active: true, step: 0 };
  emit();
}
function stop() {
  state = { active: false, step: 0 };
  emit();
}
function next() {
  state = { ...state, step: Math.min(state.step + 1, STEPS.length - 1) };
  emit();
}

function useTour() {
  const [, force] = useState(0);
  useEffect(() => {
    const l = () => force((v) => v + 1);
    listeners.add(l);
    return () => {
      listeners.delete(l);
    };
  }, []);
  return state;
}

export function InteractiveTourOverlay() {
  const { active, step: si } = useTour();
  const step = STEPS[si];
  const [rect, setRect] = useState<DOMRect | null>(null);
  const rafRef = useRef<number | null>(null);

  // Poll for target rect (handles route changes, scroll, layout shifts)
  useEffect(() => {
    if (!active || !step?.target) {
      setRect(null);
      return;
    }
    let stopped = false;
    const tick = () => {
      if (stopped) return;
      const el = document.querySelector(step.target!) as HTMLElement | null;
      if (el) {
        const r = el.getBoundingClientRect();
        setRect((prev) =>
          prev &&
          prev.top === r.top &&
          prev.left === r.left &&
          prev.width === r.width &&
          prev.height === r.height
            ? prev
            : r,
        );
      } else {
        setRect(null);
      }
      rafRef.current = requestAnimationFrame(tick);
    };
    tick();
    return () => {
      stopped = true;
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
    };
  }, [active, si, step?.target]);

  // Scroll target into view when it shows up
  useEffect(() => {
    if (!active || !step?.target) return;
    const t = setTimeout(() => {
      const el = document.querySelector(step.target!) as HTMLElement | null;
      el?.scrollIntoView({ behavior: "smooth", block: "center" });
    }, 250);
    return () => clearTimeout(t);
  }, [active, si, step?.target]);

  // Advance on real click of the target
  useEffect(() => {
    if (!active || step?.advance !== "click" || !step?.target) return;
    const handler = (e: PointerEvent) => {
      const el = document.querySelector(step.target!);
      if (el && e.target instanceof Node && el.contains(e.target)) {
        setTimeout(() => next(), 60);
      }
    };
    document.addEventListener("pointerdown", handler, true);
    return () => document.removeEventListener("pointerdown", handler, true);
  }, [active, si, step?.advance, step?.target]);

  if (!active || !step) return null;

  const pad = 10;
  const vh = typeof window !== "undefined" ? window.innerHeight : 800;

  let tipStyle: React.CSSProperties;
  if (rect) {
    const spaceBelow = vh - (rect.bottom + pad);
    const below = spaceBelow > 240;
    tipStyle = below
      ? { top: rect.bottom + pad + 14, left: 12, right: 12 }
      : { bottom: vh - rect.top + pad + 14, left: 12, right: 12 };
  } else {
    tipStyle = { top: "50%", left: 12, right: 12, transform: "translateY(-50%)" };
  }

  const isLast = si === STEPS.length - 1;

  return (
    <div className="fixed inset-0 z-[60] pointer-events-none">
      {rect ? (
        <>
          {/* Cutout backdrop via giant box-shadow */}
          <div
            aria-hidden
            style={{
              position: "fixed",
              top: rect.top - pad,
              left: rect.left - pad,
              width: rect.width + pad * 2,
              height: rect.height + pad * 2,
              borderRadius: 18,
              boxShadow: "0 0 0 9999px rgba(0,0,0,0.72)",
              outline: "2px solid var(--primary)",
              outlineOffset: 0,
              transition: "top 200ms ease, left 200ms ease, width 200ms ease, height 200ms ease",
            }}
          />
          {/* Pulsing ring */}
          <div
            aria-hidden
            className="animate-ping"
            style={{
              position: "fixed",
              top: rect.top - pad,
              left: rect.left - pad,
              width: rect.width + pad * 2,
              height: rect.height + pad * 2,
              borderRadius: 18,
              border: "2px solid var(--primary)",
              opacity: 0.5,
            }}
          />
        </>
      ) : (
        <div className="absolute inset-0 bg-black/70" />
      )}

      {/* Tooltip card */}
      <div
        className="absolute pointer-events-auto"
        style={tipStyle}
        role="dialog"
        aria-modal="true"
      >
        <div className="panel p-4 sm:p-5 max-w-md mx-auto relative animate-in fade-in zoom-in-95">
          <button
            onClick={stop}
            aria-label="Encerrar tutorial"
            className="absolute top-2 right-2 p-1.5 rounded-md hover:bg-accent text-muted-foreground"
          >
            <X className="size-4" />
          </button>
          <div className="flex items-center gap-1.5 text-[10px] font-mono uppercase tracking-widest text-muted-foreground">
            <Sparkles className="size-3.5 text-primary" />
            Passo {si + 1} de {STEPS.length}
          </div>
          <h3 className="mt-1 text-base font-bold leading-tight pr-6">
            {step.title}
          </h3>
          <p className="mt-1.5 text-sm text-muted-foreground leading-relaxed">
            {step.body}
          </p>
          {step.hint && (
            <p className="mt-2 text-xs rounded-md bg-accent/60 text-accent-foreground p-2 leading-relaxed">
              💡 {step.hint}
            </p>
          )}

          {/* Progress dots */}
          <div className="mt-3 flex items-center gap-1">
            {STEPS.map((_, idx) => (
              <span
                key={idx}
                className={`h-1 rounded-full transition-all ${
                  idx === si
                    ? "w-6 bg-primary"
                    : idx < si
                      ? "w-3 bg-primary/50"
                      : "w-3 bg-muted"
                }`}
              />
            ))}
          </div>

          <div className="mt-4 flex items-center justify-between gap-2">
            <button
              onClick={stop}
              className="text-xs text-muted-foreground hover:text-foreground underline-offset-2 hover:underline"
            >
              Encerrar
            </button>
            {step.advance === "click" ? (
              <span className="text-xs text-primary font-semibold inline-flex items-center gap-1.5">
                <MousePointerClick className="size-3.5" /> Toque no destaque
              </span>
            ) : isLast ? (
              <button
                onClick={stop}
                className="inline-flex items-center gap-1.5 px-3 py-2 text-sm font-semibold rounded-md bg-primary text-primary-foreground hover:opacity-90"
              >
                Concluir
              </button>
            ) : (
              <button
                onClick={next}
                className="inline-flex items-center gap-1.5 px-3 py-2 text-sm font-semibold rounded-md bg-primary text-primary-foreground hover:opacity-90"
              >
                Vamos lá <ArrowRight className="size-3.5" />
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
