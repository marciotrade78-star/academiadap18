import { useEffect, useState } from "react";

const SESSION_KEY = "p18-splash-shown";

/**
 * In-app splash overlay shown briefly on first paint to mask the white
 * flash when launching the installed PWA. Renders client-only and only
 * once per browser session to avoid covering the app on re-renders or
 * after a hydration mismatch.
 */
export function SplashScreen() {
  const [mounted, setMounted] = useState(false);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    setMounted(true);
    try {
      if (sessionStorage.getItem(SESSION_KEY) === "1") return;
      sessionStorage.setItem(SESSION_KEY, "1");
    } catch {
      // ignore storage errors
    }
    setVisible(true);
    const hideT = setTimeout(() => setVisible(false), 1800);
    return () => clearTimeout(hideT);
  }, []);

  if (!mounted || !visible) return null;

  return (
    <div
      aria-hidden
      style={{
        position: "fixed",
        inset: 0,
        zIndex: 9999,
        backgroundColor: "#0d1722",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        pointerEvents: "none",
        animation: "p18-splash-auto-hide 1.8s ease-out forwards",
      }}
    >
      <img
        src="/logo-p18.png"
        alt=""
        style={{
          width: "40vw",
          maxWidth: 180,
          aspectRatio: "1 / 1",
          borderRadius: "50%",
          objectFit: "cover",
          animation: "p18-splash-pulse 1.4s ease-in-out infinite",
        }}
      />
      <style>{`
        @keyframes p18-splash-auto-hide {
          0%, 60% { opacity: 1; }
          100% { opacity: 0; visibility: hidden; }
        }
        @keyframes p18-splash-pulse {
          0%, 100% { transform: scale(1); opacity: 0.9; }
          50% { transform: scale(1.06); opacity: 1; }
        }
      `}</style>
    </div>
  );
}
