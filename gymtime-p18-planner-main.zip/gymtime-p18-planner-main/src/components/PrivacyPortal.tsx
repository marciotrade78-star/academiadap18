import { useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import { Download, ShieldCheck, Trash2, FileText } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

export function PrivacyPortal({ userId }: { userId: string }) {
  void userId;
  const navigate = useNavigate();
  const [loading, setLoading] = useState<"export" | "delete" | null>(null);
  const [confirmText, setConfirmText] = useState("");
  const [showDelete, setShowDelete] = useState(false);

  async function handleExport() {
    setLoading("export");
    try {
      const { data, error } = await supabase.rpc("export_my_data");
      if (error) throw error;
      const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `meus-dados-p18-${new Date().toISOString().slice(0, 10)}.json`;
      a.click();
      URL.revokeObjectURL(url);
      toast.success("Dados exportados.");
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Falha ao exportar.");
    } finally {
      setLoading(null);
    }
  }

  async function handleDelete() {
    if (confirmText !== "EXCLUIR") {
      toast.error('Digite "EXCLUIR" para confirmar.');
      return;
    }
    setLoading("delete");
    try {
      const { error } = await supabase.rpc("delete_my_account");
      if (error) throw error;
      await supabase.auth.signOut();
      toast.success("Conta excluída.");
      navigate({ to: "/" });
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Falha ao excluir conta.");
      setLoading(null);
    }
  }

  return (
    <section className="panel p-5 space-y-4">
      <header className="flex items-center gap-2">
        <ShieldCheck className="size-5 text-primary" />
        <h2 className="font-semibold">Privacidade e seus direitos (LGPD)</h2>
      </header>
      <p className="text-xs text-muted-foreground">
        Em conformidade com a Lei nº 13.709/2018, você pode acessar, exportar e eliminar seus dados pessoais a qualquer momento.
      </p>

      <div className="grid gap-2 sm:grid-cols-2">
        <a
          href="/privacidade"
          target="_blank"
          rel="noreferrer"
          className="inline-flex items-center gap-2 px-3 py-2 rounded-md border border-border text-sm hover:bg-muted"
        >
          <FileText className="size-4" /> Política de Privacidade
        </a>
        <a
          href="/termos"
          target="_blank"
          rel="noreferrer"
          className="inline-flex items-center gap-2 px-3 py-2 rounded-md border border-border text-sm hover:bg-muted"
        >
          <FileText className="size-4" /> Termos de Uso
        </a>
      </div>

      <button
        onClick={handleExport}
        disabled={loading !== null}
        className="w-full inline-flex items-center justify-center gap-2 px-3 py-2 rounded-md bg-primary text-primary-foreground text-sm font-semibold hover:bg-primary/90 disabled:opacity-60"
      >
        <Download className="size-4" />
        {loading === "export" ? "Exportando..." : "Exportar meus dados (JSON)"}
      </button>

      {!showDelete ? (
        <button
          onClick={() => setShowDelete(true)}
          className="w-full inline-flex items-center justify-center gap-2 px-3 py-2 rounded-md border border-destructive/40 text-destructive text-sm hover:bg-destructive/10"
        >
          <Trash2 className="size-4" /> Excluir minha conta
        </button>
      ) : (
        <div className="rounded-md border border-destructive/40 p-3 space-y-2 bg-destructive/5">
          <p className="text-xs">
            Esta ação é <strong>irreversível</strong>. Sua conta, perfil, agendamentos e consentimentos serão apagados.
            Para confirmar, digite <strong>EXCLUIR</strong> abaixo.
          </p>
          <input
            value={confirmText}
            onChange={(e) => setConfirmText(e.target.value)}
            className="w-full px-3 py-2 rounded-md bg-background border border-border text-sm"
            placeholder="EXCLUIR"
          />
          <div className="flex gap-2">
            <button
              onClick={() => { setShowDelete(false); setConfirmText(""); }}
              className="flex-1 px-3 py-2 rounded-md border border-border text-sm"
            >Cancelar</button>
            <button
              onClick={handleDelete}
              disabled={loading !== null}
              className="flex-1 px-3 py-2 rounded-md bg-destructive text-destructive-foreground text-sm font-semibold disabled:opacity-60"
            >
              {loading === "delete" ? "Excluindo..." : "Confirmar exclusão"}
            </button>
          </div>
        </div>
      )}
    </section>
  );
}
