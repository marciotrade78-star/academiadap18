import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Megaphone, Trash2, ChevronDown, ChevronRight, Send, Eye, EyeOff } from "lucide-react";
import { toast } from "sonner";

type Announcement = {
  id: string;
  title: string;
  message: string;
  active: boolean;
  created_at: string;
};

export function AnnouncementsAdmin() {
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);
  const [title, setTitle] = useState("");
  const [message, setMessage] = useState("");

  const { data: announcements = [], isLoading } = useQuery({
    queryKey: ["admin-announcements"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("announcements" as never)
        .select("id, title, message, active, created_at")
        .order("created_at", { ascending: false });
      if (error) throw error;
      return (data ?? []) as unknown as Announcement[];
    },
  });

  const { data: ackCounts = {} } = useQuery({
    queryKey: ["admin-announcement-acks", announcements.map((a) => a.id).join(",")],
    enabled: announcements.length > 0,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("announcement_acknowledgements" as never)
        .select("announcement_id");
      if (error) throw error;
      const counts: Record<string, number> = {};
      for (const row of (data ?? []) as unknown as { announcement_id: string }[]) {
        counts[row.announcement_id] = (counts[row.announcement_id] ?? 0) + 1;
      }
      return counts;
    },
  });

  const create = useMutation({
    mutationFn: async () => {
      const { data: u } = await supabase.auth.getUser();
      const { error } = await supabase.from("announcements" as never).insert({
        title: title.trim(),
        message: message.trim(),
        created_by: u.user?.id ?? null,
        active: true,
      } as never);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Aviso enviado a todos os usuários.");
      setTitle("");
      setMessage("");
      qc.invalidateQueries({ queryKey: ["admin-announcements"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const toggleActive = useMutation({
    mutationFn: async ({ id, active }: { id: string; active: boolean }) => {
      const { error } = await supabase
        .from("announcements" as never)
        .update({ active } as never)
        .eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["admin-announcements"] }),
    onError: (e: Error) => toast.error(e.message),
  });

  const remove = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("announcements" as never).delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Aviso removido.");
      qc.invalidateQueries({ queryKey: ["admin-announcements"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const canSubmit = title.trim().length > 0 && message.trim().length > 0 && !create.isPending;

  return (
    <section className="panel p-4">
      <header className="flex items-center justify-between mb-3">
        <h2 className="inline-flex items-center gap-2 font-bold text-primary">
          <Megaphone className="size-4" /> Avisos a todos os usuários
        </h2>
        <button
          type="button"
          onClick={() => setOpen((v) => !v)}
          className="p-1.5 rounded-md hover:bg-muted text-muted-foreground"
          aria-label={open ? "Recolher" : "Expandir"}
        >
          {open ? <ChevronDown className="size-4" /> : <ChevronRight className="size-4" />}
        </button>
      </header>

      {open && (
        <>
          <p className="text-xs text-muted-foreground mb-3">
            Envie uma mensagem, alerta ou notificação. Ela aparecerá para cada usuário ao abrir o aplicativo, e somente sumirá quando o usuário clicar em "Ciente".
          </p>

          <form
            onSubmit={(e) => {
              e.preventDefault();
              if (canSubmit) create.mutate();
            }}
            className="grid gap-2 mb-4"
          >
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Título do aviso"
              maxLength={120}
              className="w-full rounded-md border border-border bg-background px-3 py-2 text-sm"
            />
            <textarea
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Mensagem para os usuários"
              rows={4}
              maxLength={2000}
              className="w-full rounded-md border border-border bg-background px-3 py-2 text-sm resize-y"
            />
            <button
              type="submit"
              disabled={!canSubmit}
              className="inline-flex items-center justify-center gap-2 rounded-md bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground hover:bg-primary/90 disabled:opacity-50"
            >
              <Send className="size-4" />
              {create.isPending ? "Enviando..." : "Enviar a todos"}
            </button>
          </form>

          <div className="grid gap-2">
            {isLoading ? (
              <p className="text-sm text-muted-foreground">Carregando...</p>
            ) : announcements.length === 0 ? (
              <p className="text-sm text-muted-foreground">Nenhum aviso criado ainda.</p>
            ) : (
              announcements.map((a) => (
                <article key={a.id} className="rounded-lg border border-border p-3">
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <h3 className="font-semibold text-sm break-words">{a.title}</h3>
                        <span
                          className={`text-[10px] uppercase tracking-wide rounded px-1.5 py-0.5 ${a.active ? "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400" : "bg-muted text-muted-foreground"}`}
                        >
                          {a.active ? "Ativo" : "Inativo"}
                        </span>
                      </div>
                      <p className="text-xs text-muted-foreground mt-1 whitespace-pre-wrap break-words">
                        {a.message}
                      </p>
                      <p className="text-[11px] text-muted-foreground mt-2">
                        {new Date(a.created_at).toLocaleString("pt-BR")} ·{" "}
                        {ackCounts[a.id] ?? 0} ciência(s)
                      </p>
                    </div>
                    <div className="flex flex-col gap-1 shrink-0">
                      <button
                        type="button"
                        onClick={() => toggleActive.mutate({ id: a.id, active: !a.active })}
                        className="inline-flex items-center justify-center rounded-md border border-border p-1.5 hover:bg-muted"
                        title={a.active ? "Desativar" : "Reativar"}
                        aria-label={a.active ? "Desativar" : "Reativar"}
                      >
                        {a.active ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          if (confirm("Remover este aviso? As ciências também serão apagadas.")) {
                            remove.mutate(a.id);
                          }
                        }}
                        className="inline-flex items-center justify-center rounded-md border border-destructive/30 p-1.5 text-destructive hover:bg-destructive/10"
                        title="Remover"
                        aria-label="Remover"
                      >
                        <Trash2 className="size-4" />
                      </button>
                    </div>
                  </div>
                </article>
              ))
            )}
          </div>
        </>
      )}
    </section>
  );
}
