import { useEffect, useState } from "react";
import QRCode from "qrcode";
import { Share2, QrCode, X } from "lucide-react";
import { Button } from "@/components/ui/button";

const PUBLIC_URL = "https://www.academiadap18.com.br";
const SHARE_MESSAGE =
  "Use o app P-18 para reservar seu horário nas academias de musculação e aeróbica:";

export function ShareApp() {
  const [open, setOpen] = useState(false);
  const [qr, setQr] = useState<string | null>(null);

  useEffect(() => {
    if (!open) return;
    QRCode.toDataURL(PUBLIC_URL, { width: 320, margin: 1 }).then(setQr).catch(() => setQr(null));
  }, [open]);

  function shareWhats() {
    const text = encodeURIComponent(`${SHARE_MESSAGE} ${PUBLIC_URL}`);
    window.open(`https://wa.me/?text=${text}`, "_blank", "noopener,noreferrer");
  }

  return (
    <>
      <div className="panel p-4">
        <div className="flex items-start justify-between gap-4">
          <div className="min-w-0">
            <h3 className="font-semibold text-sm">Compartilhar o app</h3>
            <p className="mt-1 text-xs text-muted-foreground">
              Envie para um colega via WhatsApp ou QR Code.
            </p>
            <Button onClick={() => setOpen(true)} size="sm" className="mt-3">
              <Share2 className="mr-2 h-3.5 w-3.5" /> Compartilhar
            </Button>
          </div>
        </div>
      </div>

      {open && (
        <div
          className="fixed inset-0 z-50 grid place-items-center bg-black/60 p-4"
          onClick={() => setOpen(false)}
        >
          <div
            className="w-full max-w-sm rounded-xl bg-card border border-border p-5 relative"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              onClick={() => setOpen(false)}
              className="absolute top-3 right-3 p-1 rounded-md hover:bg-accent"
              aria-label="Fechar"
            >
              <X className="h-4 w-4" />
            </button>
            <h3 className="font-semibold">Compartilhar P-18</h3>
            <p className="text-xs text-muted-foreground mt-1">
              Escaneie o QR Code com a câmera de outro celular ou envie pelo WhatsApp.
            </p>

            <div className="mt-4 grid place-items-center bg-white rounded-lg p-3">
              {qr ? (
                <img src={qr} alt="QR Code do app" className="w-56 h-56" />
              ) : (
                <div className="w-56 h-56 grid place-items-center text-muted-foreground">
                  <QrCode className="size-10" />
                </div>
              )}
            </div>

            <p className="mt-3 text-center text-xs font-mono text-muted-foreground break-all">
              {PUBLIC_URL}
            </p>

            <div className="mt-4 grid gap-2">
              <Button onClick={shareWhats} className="w-full font-semibold">
                <Share2 className="mr-2 h-4 w-4" /> Enviar pelo WhatsApp
              </Button>
              <Button
                variant="outline"
                onClick={() => {
                  navigator.clipboard.writeText(PUBLIC_URL);
                }}
                className="w-full"
              >
                Copiar link
              </Button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
