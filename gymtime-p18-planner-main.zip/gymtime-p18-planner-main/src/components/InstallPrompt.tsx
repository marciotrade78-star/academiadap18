import { useEffect, useState } from "react";
import { Download } from "lucide-react";
import { Button } from "@/components/ui/button";
import { InstallHelp } from "@/components/InstallHelp";

interface BeforeInstallPromptEvent extends Event {
  prompt(): Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed" }>;
}

export function InstallPrompt() {
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [isStandalone, setIsStandalone] = useState(false);

  useEffect(() => {
    // Only hide when the app is actually running as the installed PWA.
    // In a regular browser tab the card always shows — even if the app was
    // installed before — so users who deleted the icon can put it back.
    const standalone =
      window.matchMedia("(display-mode: standalone)").matches ||
      (navigator as Navigator & { standalone?: boolean }).standalone === true;
    setIsStandalone(standalone);

    const handleBeforeInstallPrompt = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e as BeforeInstallPromptEvent);
    };

    window.addEventListener("beforeinstallprompt", handleBeforeInstallPrompt);
    return () => {
      window.removeEventListener("beforeinstallprompt", handleBeforeInstallPrompt);
    };
  }, []);

  const handleInstall = async () => {
    if (!deferredPrompt) return;
    await deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    if (outcome === "accepted") {
      setDeferredPrompt(null);
    }
  };

  if (isStandalone) return null;

  return (
    <div className="panel p-4">
      <div className="min-w-0 flex-1">
        <h3 className="font-semibold text-sm">Instalar no celular</h3>
        <p className="mt-1 text-xs text-muted-foreground">
          Adicione o P-18 à tela inicial para acesso rápido como um app. Se já
          instalou antes e apagou o ícone, use o botão abaixo para colocá-lo
          de volta.
        </p>
        <div className="mt-3">
          {deferredPrompt ? (
            <Button onClick={handleInstall} size="sm">
              <Download className="mr-2 h-3.5 w-3.5" />
              Instalar
            </Button>
          ) : (
            <InstallHelp variant="button" label="Instalar" />
          )}
        </div>
      </div>
    </div>
  );
}
