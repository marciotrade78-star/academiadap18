import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { MessageSquarePlus, Lightbulb, Bug } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

type FeedbackType = "sugestao" | "erro";

export function FeedbackForm() {
  const qc = useQueryClient();
  const [type, setType] = useState<FeedbackType>("sugestao");
  const [message, setMessage] = useState("");

  const send = useMutation({
    mutationFn: async () => {
      const msg = message.trim();
      if (msg.length < 5) throw new Error("Escreva pelo menos 5 caracteres.");
      if (msg.length > 1000) throw new Error("Máximo 1000 caracteres.");
      const { data: u } = await supabase.auth.getUser();
      if (!u.user) throw new Error("Sessão expirada.");
      const { error } = await supabase.from("feedback").insert({
        user_id: u.user.id,
        type,
        message: msg,
      });
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Obrigado pelo seu feedback!");
      setMessage("");
      setType("sugestao");
      qc.invalidateQueries({ queryKey: ["admin-feedback"] });
    },
    onError: (e: Error) => toast.error(e.message || "Erro ao enviar."),
  });

  return (
    <div className="panel p-4">
      <div className="flex items-start gap-2">
        <MessageSquarePlus className="size-4 text-primary mt-0.5" />
        <div className="min-w-0 flex-1">
          <h3 className="font-semibold text-sm">Sugestões e erros</h3>
          <p className="mt-1 text-xs text-muted-foreground">
            Envie uma sugestão de melhoria ou relate um problema.
          </p>

          <div className="mt-3 grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={() => setType("sugestao")}
              className={`inline-flex items-center justify-center gap-1.5 rounded-md px-3 py-2 text-xs font-semibold border transition-colors ${
                type === "sugestao"
                  ? "bg-primary text-primary-foreground border-primary"
                  : "bg-background text-foreground border-border hover:bg-accent"
              }`}
            >
              <Lightbulb className="size-3.5" /> Sugestão
            </button>
            <button
              type="button"
              onClick={() => setType("erro")}
              className={`inline-flex items-center justify-center gap-1.5 rounded-md px-3 py-2 text-xs font-semibold border transition-colors ${
                type === "erro"
                  ? "bg-destructive text-destructive-foreground border-destructive"
                  : "bg-background text-foreground border-border hover:bg-accent"
              }`}
            >
              <Bug className="size-3.5" /> Reportar erro
            </button>
          </div>

          <textarea
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            maxLength={1000}
            rows={3}
            placeholder={
              type === "sugestao"
                ? "Descreva sua sugestão de melhoria..."
                : "Descreva o erro encontrado..."
            }
            className="mt-3 w-full rounded-md border border-border bg-input px-3 py-2 text-sm placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
          />
          <div className="mt-1 text-right text-[10px] font-mono text-muted-foreground">
            {message.length}/1000
          </div>

          <Button
            onClick={() => send.mutate()}
            disabled={send.isPending || message.trim().length < 5}
            size="sm"
            className="mt-2 w-full font-semibold"
          >
            {send.isPending ? "Enviando..." : "Enviar"}
          </Button>
        </div>
      </div>
    </div>
  );
}
