import { useEffect } from "react";
import { Sparkles, ArrowRight } from "lucide-react";
import { startInteractiveTour } from "@/components/InteractiveTour";

const STORAGE_KEY = "p18.tour.completed.v2";

export function AppTour() {
  // Auto-launch the interactive simulation on first visit
  useEffect(() => {
    try {
      if (!localStorage.getItem(STORAGE_KEY)) {
        const t = setTimeout(() => {
          startInteractiveTour();
          localStorage.setItem(STORAGE_KEY, "1");
        }, 600);
        return () => clearTimeout(t);
      }
    } catch {
      /* ignore */
    }
  }, []);

  return (
    <button
      type="button"
      onClick={() => startInteractiveTour()}
      className="panel w-full p-4 flex items-center gap-3 text-left hover:border-[color:var(--ring)] transition"
    >
      <span
        className="grid place-items-center size-10 rounded-full"
        style={{
          background: "color-mix(in oklab, var(--primary) 15%, transparent)",
          color: "var(--primary)",
        }}
      >
        <Sparkles className="size-5" />
      </span>
      <span className="flex-1">
        <span className="block text-sm font-semibold">
          Aprender fazendo: simular uma reserva
        </span>
        <span className="block text-xs text-muted-foreground">
          Eu te guio passo a passo na tela — você toca, eu mostro o resultado.
        </span>
      </span>
      <ArrowRight className="size-4 text-muted-foreground" />
    </button>
  );
}
