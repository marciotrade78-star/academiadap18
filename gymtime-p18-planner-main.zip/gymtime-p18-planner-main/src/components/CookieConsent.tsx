import { useEffect, useState } from "react";
import { Link } from "@tanstack/react-router";
import { Cookie } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

const STORAGE_KEY = "p18-cookie-consent-v1";

type Prefs = {
  functional: boolean; // sempre true (essenciais)
  analytics: boolean;
  decidedAt: string;
};

export function getCookieConsent(): Prefs | null {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? (JSON.parse(raw) as Prefs) : null;
  } catch {
    return null;
  }
}

async function recordConsent(analytics: boolean) {
  const { data } = await supabase.auth.getUser();
  const uid = data.user?.id;
  if (!uid) return;
  await supabase.from("consents").insert([
    { user_id: uid, tipo: "cookies_functional", version: "1.0.0", granted: true, user_agent: navigator.userAgent },
    { user_id: uid, tipo: "cookies_analytics", version: "1.0.0", granted: analytics, user_agent: navigator.userAgent },
  ]);
}

export function CookieConsent() {
  const [visible, setVisible] = useState(false);
  const [showPrefs, setShowPrefs] = useState(false);
  const [analytics, setAnalytics] = useState(true);

  useEffect(() => {
    if (!getCookieConsent()) setVisible(true);
  }, []);

  function save(prefs: { analytics: boolean }) {
    const value: Prefs = {
      functional: true,
      analytics: prefs.analytics,
      decidedAt: new Date().toISOString(),
    };
    localStorage.setItem(STORAGE_KEY, JSON.stringify(value));
    recordConsent(prefs.analytics).catch(() => {});
    setVisible(false);
  }

  if (!visible) return null;

  return (
    <div className="fixed inset-x-0 bottom-0 z-[100] p-3 sm:p-4 pointer-events-none">
      <div className="mx-auto max-w-2xl rounded-xl border border-border bg-card/95 backdrop-blur shadow-2xl p-4 sm:p-5 pointer-events-auto">
        <div className="flex items-start gap-3">
          <Cookie className="size-5 text-primary shrink-0 mt-0.5" />
          <div className="flex-1 text-sm">
            <p className="font-semibold">Cookies e privacidade</p>
            <p className="mt-1 text-muted-foreground text-xs sm:text-sm">
              Usamos cookies essenciais para o funcionamento da plataforma e, com seu consentimento,
              cookies analíticos para melhorar sua experiência. Veja nossa{" "}
              <Link to="/privacidade" className="underline text-primary">Política de Privacidade</Link>.
            </p>

            {showPrefs && (
              <div className="mt-3 space-y-2 rounded-md border border-border p-3 bg-muted/40">
                <label className="flex items-start gap-2 text-xs">
                  <input type="checkbox" checked disabled className="mt-0.5" />
                  <span><strong>Essenciais</strong> — necessários para autenticação e reservas. Sempre ativos.</span>
                </label>
                <label className="flex items-start gap-2 text-xs cursor-pointer">
                  <input
                    type="checkbox"
                    checked={analytics}
                    onChange={(e) => setAnalytics(e.target.checked)}
                    className="mt-0.5"
                  />
                  <span><strong>Analíticos</strong> — nos ajudam a entender o uso da plataforma de forma anônima.</span>
                </label>
              </div>
            )}

            <div className="mt-3 flex flex-wrap gap-2">
              <button
                onClick={() => save({ analytics: false })}
                className="px-3 py-1.5 rounded-md border border-border text-xs hover:bg-muted"
              >Apenas essenciais</button>
              {!showPrefs && (
                <button
                  onClick={() => setShowPrefs(true)}
                  className="px-3 py-1.5 rounded-md border border-border text-xs hover:bg-muted"
                >Personalizar</button>
              )}
              {showPrefs ? (
                <button
                  onClick={() => save({ analytics })}
                  className="px-3 py-1.5 rounded-md bg-primary text-primary-foreground text-xs font-semibold"
                >Salvar preferências</button>
              ) : (
                <button
                  onClick={() => save({ analytics: true })}
                  className="px-3 py-1.5 rounded-md bg-primary text-primary-foreground text-xs font-semibold"
                >Aceitar todos</button>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
