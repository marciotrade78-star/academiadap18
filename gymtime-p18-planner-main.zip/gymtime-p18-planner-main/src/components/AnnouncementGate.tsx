import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Megaphone, CheckCircle2 } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

type PendingAnnouncement = {
  id: string;
  title: string;
  message: string;
  created_at: string;
};

export function AnnouncementGate() {
  const [userId, setUserId] = useState<string | null>(null);
  const [pending, setPending] = useState<PendingAnnouncement[]>([]);
  const [submitting, setSubmitting] = useState(false);

  // Track auth user
  useEffect(() => {
    let mounted = true;
    supabase.auth.getUser().then(({ data }) => {
      if (mounted) setUserId(data.user?.id ?? null);
    });
    const { data: sub } = supabase.auth.onAuthStateChange((_e, session) => {
      setUserId(session?.user?.id ?? null);
    });
    return () => {
      mounted = false;
      sub.subscription.unsubscribe();
    };
  }, []);

  // Fetch pending announcements when user is set
  useEffect(() => {
    if (!userId) {
      setPending([]);
      return;
    }
    let cancelled = false;
    (async () => {
      const { data: anns, error } = await supabase
        .from("announcements" as never)
        .select("id, title, message, created_at")
        .eq("active", true)
        .order("created_at", { ascending: true });
      if (error || !anns) return;
      const list = anns as unknown as PendingAnnouncement[];
      if (list.length === 0) {
        if (!cancelled) setPending([]);
        return;
      }
      const { data: acks } = await supabase
        .from("announcement_acknowledgements" as never)
        .select("announcement_id")
        .eq("user_id", userId);
      const ackSet = new Set(
        ((acks ?? []) as unknown as { announcement_id: string }[]).map((r) => r.announcement_id),
      );
      const filtered = list.filter((a) => !ackSet.has(a.id));
      if (!cancelled) setPending(filtered);
    })();
    return () => {
      cancelled = true;
    };
  }, [userId]);

  const current = pending[0];

  async function acknowledge() {
    if (!current || !userId) return;
    setSubmitting(true);
    const { error } = await supabase
      .from("announcement_acknowledgements" as never)
      .insert({ announcement_id: current.id, user_id: userId } as never);
    setSubmitting(false);
    if (error && !error.message.toLowerCase().includes("duplicate")) {
      return;
    }
    setPending((prev) => prev.slice(1));
  }

  if (!current) return null;

  return (
    <Dialog open={true} onOpenChange={() => { /* lock — must acknowledge */ }}>
      <DialogContent
        className="sm:max-w-md"
        onPointerDownOutside={(e) => e.preventDefault()}
        onEscapeKeyDown={(e) => e.preventDefault()}
        onInteractOutside={(e) => e.preventDefault()}
      >
        <DialogHeader>
          <DialogTitle className="inline-flex items-center gap-2 text-primary">
            <Megaphone className="size-5" />
            {current.title}
          </DialogTitle>
          <DialogDescription className="text-xs">
            {new Date(current.created_at).toLocaleString("pt-BR")}
          </DialogDescription>
        </DialogHeader>
        <div className="text-sm whitespace-pre-wrap break-words text-foreground">
          {current.message}
        </div>
        <DialogFooter>
          <button
            type="button"
            onClick={acknowledge}
            disabled={submitting}
            className="inline-flex w-full items-center justify-center gap-2 rounded-md bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground hover:bg-primary/90 disabled:opacity-50"
          >
            <CheckCircle2 className="size-4" />
            {submitting ? "Confirmando..." : "Ciente"}
          </button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
