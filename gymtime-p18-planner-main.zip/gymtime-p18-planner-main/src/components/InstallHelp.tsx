import { useState, useEffect } from "react";
import { Download, X, Share2, PlusSquare, Smartphone, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";

interface BeforeInstallPromptEvent extends Event {
  prompt(): Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed" }>;
}

interface InstallHelpProps {
  variant?: "link" | "button";
  label?: string;
}

function isIOS() {
  if (typeof navigator === "undefined") return false;
  return (
    /iPad|iPhone|iPod/.test(navigator.userAgent) ||
    (navigator.platform === "MacIntel" && "standalone" in navigator)
  );
}

function isStandalone() {
  if (typeof window === "undefined") return false;
  return window.matchMedia("(display-mode: standalone)").matches ||
    ("standalone" in navigator && (navigator as Navigator & { standalone?: boolean }).standalone === true);
}

export function InstallHelp({ variant = "link", label }: InstallHelpProps) {
  const [open, setOpen] = useState(false);
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [isInstalled, setIsInstalled] = useState(false);

  useEffect(() => {
    if (isStandalone()) {
      setIsInstalled(true);
      return;
    }

    const handleBeforeInstallPrompt = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e as BeforeInstallPromptEvent);
    };

    window.addEventListener("beforeinstallprompt", handleBeforeInstallPrompt);
    return () => {
      window.removeEventListener("beforeinstallprompt", handleBeforeInstallPrompt);
    };
  }, []);

  const handleNativeInstall = async () => {
    if (!deferredPrompt) return;
    await deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    if (outcome === "accepted") {
      setDeferredPrompt(null);
      setIsInstalled(true);
      setOpen(false);
    }
  };

  // Always show the button — even if already installed, the user may have removed
  // the icon from the home screen and needs to reinstall it.

  const ios = isIOS();
  const canInstallNative = !!deferredPrompt;

  const displayLabel = label || (isInstalled ? "Reinstalar ícone do app" : "Adicionar à tela inicial");

  return (
    <>
      {variant === "button" ? (
        <Button
          type="button"
          variant="outline"
          size="sm"
          onClick={() => setOpen(true)}
          className="w-full"
        >
          <RefreshCw className="mr-2 size-4" />
          {displayLabel}
        </Button>
      ) : (
        <button
          type="button"
          onClick={() => setOpen(true)}
          className="inline-flex items-center gap-1.5 text-xs text-primary hover:underline"
        >
          <Smartphone className="size-3.5" />
          {displayLabel}
        </button>
      )}

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle className="text-base">Instalar o app</DialogTitle>
            <DialogDescription>
              Adicione o P-18 à tela inicial para acesso rápido como um app nativo.
            </DialogDescription>
          </DialogHeader>

          <div className="mt-2 space-y-4">
            {canInstallNative && (
              <Button onClick={handleNativeInstall} className="w-full">
                <Download className="mr-2 size-4" />
                Instalar agora
              </Button>
            )}

            {ios && (
              <div className="rounded-lg border bg-muted/50 p-4 space-y-3">
                <p className="text-sm font-medium">No iPhone / iPad:</p>
                <ol className="space-y-2 text-sm text-muted-foreground">
                  <li className="flex items-start gap-2">
                    <span className="mt-0.5 inline-flex items-center justify-center rounded-full bg-primary/10 size-5 text-xs font-semibold text-primary shrink-0">1</span>
                    <span>Toque no botão <Share2 className="inline size-3.5 mx-0.5 align-text-bottom" /> Compartilhar na barra do Safari.</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="mt-0.5 inline-flex items-center justify-center rounded-full bg-primary/10 size-5 text-xs font-semibold text-primary shrink-0">2</span>
                    <span>Role para baixo e toque em <strong>Adicionar à Tela de Início</strong> <PlusSquare className="inline size-3.5 mx-0.5 align-text-bottom" />.</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="mt-0.5 inline-flex items-center justify-center rounded-full bg-primary/10 size-5 text-xs font-semibold text-primary shrink-0">3</span>
                    <span>Toque em <strong>Adicionar</strong> no canto superior direito.</span>
                  </li>
                </ol>
              </div>
            )}

            {!ios && !canInstallNative && (
              <div className="rounded-lg border bg-muted/50 p-4 space-y-3">
                <p className="text-sm font-medium">No Android / Chrome:</p>
                <ol className="space-y-2 text-sm text-muted-foreground">
                  <li className="flex items-start gap-2">
                    <span className="mt-0.5 inline-flex items-center justify-center rounded-full bg-primary/10 size-5 text-xs font-semibold text-primary shrink-0">1</span>
                    <span>Toque no menu ⋮ (três pontos) no canto superior direito do Chrome.</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="mt-0.5 inline-flex items-center justify-center rounded-full bg-primary/10 size-5 text-xs font-semibold text-primary shrink-0">2</span>
                    <span>Selecione <strong>Adicionar à tela inicial</strong> ou <strong>Instalar app</strong>.</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="mt-0.5 inline-flex items-center justify-center rounded-full bg-primary/10 size-5 text-xs font-semibold text-primary shrink-0">3</span>
                    <span>Confirme para criar o atalho.</span>
                  </li>
                </ol>
              </div>
            )}

            <p className="text-center text-xs text-muted-foreground">
              Depois de instalado, abra o app pelo ícone da sua tela inicial.
            </p>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
