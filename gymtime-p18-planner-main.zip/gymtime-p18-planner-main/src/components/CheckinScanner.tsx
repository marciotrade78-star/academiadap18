import { useEffect, useRef, useState } from "react";
import { Html5Qrcode } from "html5-qrcode";
import { supabase } from "@/integrations/supabase/client";
import { type GymType } from "@/lib/slots";
import { X, CheckCircle2, XCircle, Loader2, Camera } from "lucide-react";
import { toast } from "sonner";

type Props = {
  gym: GymType;
  onClose: () => void;
  onSuccess: (result: Result) => void;
};

export type Result = { ok: boolean; reason: string; slot?: string };

const MESSAGES: Record<string, { title: string; desc: string; ok: boolean }> = {
  confirmed: { title: "Presença confirmada!", desc: "Bom treino.", ok: true },
  already: { title: "Já confirmado", desc: "Sua presença já estava registrada.", ok: true },
  no_booking: { title: "Sem reserva hoje", desc: "Você não tem reserva nesta academia para hoje.", ok: false },
  out_of_window: { title: "Fora do horário", desc: "A confirmação só é aceita de 10 min antes até 45 min após o início.", ok: false },
  too_early: { title: "Ainda não chegou seu horário", desc: "Seu horário ainda não chegou. Tente mais tarde, pelo menos 10 minutos antes do seu horário agendado.", ok: false },
  error: { title: "Erro", desc: "Não foi possível confirmar agora. Tente novamente.", ok: false },
};

function nowHMSInSP(): string {
  return new Date().toLocaleTimeString("en-GB", {
    timeZone: "America/Sao_Paulo",
    hour12: false,
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
  });
}

export function CheckinScanner({ gym, onClose, onSuccess }: Props) {
  const elementId = "checkin-qr-reader";
  const scannerRef = useRef<Html5Qrcode | null>(null);
  const handledRef = useRef(false);
  const [status, setStatus] = useState<"starting" | "scanning" | "processing" | "done" | "denied">("starting");
  const [errorMsg, setErrorMsg] = useState<string>("");
  const [result, setResult] = useState<Result | null>(null);

  useEffect(() => {
    const scanner = new Html5Qrcode(elementId, { verbose: false });
    scannerRef.current = scanner;

    const handleDecoded = async (decodedText: string) => {
      if (handledRef.current) return;

      let scannedGym: string | null = null;
      try {
        const url = new URL(decodedText);
        const match = url.pathname.match(/\/app\/checkin\/([^/?#]+)/);
        if (match) scannedGym = match[1];
      } catch {
        const match = decodedText.match(/\/app\/checkin\/([^/?#\s]+)/);
        if (match) scannedGym = match[1];
      }

      if (!scannedGym || (scannedGym !== "musculacao" && scannedGym !== "aerobica")) {
        toast.error("QR Code inválido. Use o QR Code colado na porta da academia.");
        return;
      }

      if (scannedGym !== gym) {
        toast.error("QR Code da academia errada para esta reserva.");
        return;
      }

      handledRef.current = true;
      setStatus("processing");
      try {
        await scanner.stop();
      } catch {
        // ignore
      }

      const { data, error } = await supabase.rpc("check_in_booking", { _gym: gym });
      let res: Result;
      if (error) res = { ok: false, reason: "error" };
      else res = data as Result;
      if (!res.ok && res.reason === "out_of_window" && res.slot) {
        // distinguish "too early" from "too late"
        const now = nowHMSInSP();
        if (now < res.slot) res = { ...res, reason: "too_early" };
      }
      setResult(res);
      setStatus("done");
      onSuccess(res);
      if (res.ok) {
        setTimeout(() => onClose(), 1500);
      }
    };

    scanner
      .start(
        { facingMode: "environment" },
        {
          fps: 10,
          qrbox: (vw: number, vh: number) => {
            const size = Math.floor(Math.min(vw, vh) * 0.75);
            return { width: size, height: size };
          },
          aspectRatio: 1,
        },
        (decodedText) => { void handleDecoded(decodedText); },
        () => { /* per-frame failures are normal */ },
      )
      .then(() => setStatus("scanning"))
      .catch((err: unknown) => {
        const msg = err instanceof Error ? err.message : String(err);
        setErrorMsg(msg);
        setStatus("denied");
      });

    return () => {
      const s = scannerRef.current;
      if (!s) return;
      try {
        const p = s.stop();
        if (p && typeof p.then === "function") {
          p.catch(() => undefined).finally(() => {
            try { s.clear(); } catch { /* noop */ }
          });
        } else {
          try { s.clear(); } catch { /* noop */ }
        }
      } catch {
        try { s.clear(); } catch { /* noop */ }
      }
    };
  }, [gym, onSuccess, onClose]);

  const msg = result ? MESSAGES[result.reason] ?? MESSAGES.error : null;

  return (
    <div className="fixed inset-0 z-50 bg-background/95 backdrop-blur-sm flex flex-col">
      <div className="flex items-center justify-between p-4 border-b">
        <div>
          <p className="text-xs font-mono uppercase tracking-widest text-muted-foreground">Check-in</p>
          <h2 className="text-lg font-bold">Escaneie o QR da academia</h2>
        </div>
        <button
          onClick={onClose}
          className="size-9 grid place-items-center rounded-md hover:bg-accent"
          aria-label="Fechar"
        >
          <X className="size-5" />
        </button>
      </div>

      <div className="flex-1 overflow-auto p-4 flex flex-col items-center justify-center gap-4">
        <div className={`relative w-full max-w-sm aspect-square rounded-xl overflow-hidden bg-black ${status === "done" || status === "denied" ? "hidden" : ""}`}>
          <div id={elementId} className="w-full h-full" />
          {status === "starting" && (
            <div className="absolute inset-0 grid place-items-center text-white">
              <Loader2 className="animate-spin size-6" />
            </div>
          )}
          {status === "processing" && (
            <div className="absolute inset-0 grid place-items-center bg-black/60 text-white">
              <Loader2 className="animate-spin size-6" />
            </div>
          )}
        </div>

        {status === "scanning" && (
          <p className="text-sm text-muted-foreground text-center max-w-sm">
            Aponte a câmera para o QR Code colado na porta da academia.
          </p>
        )}

        {status === "denied" && (
          <div className="panel p-6 text-center max-w-sm">
            <Camera className="mx-auto size-10 text-muted-foreground" />
            <h3 className="mt-3 font-bold">Câmera indisponível</h3>
            <p className="mt-1 text-sm text-muted-foreground">
              Permita o acesso à câmera nas configurações do navegador e tente novamente.
            </p>
            {errorMsg && <p className="mt-2 text-xs font-mono text-muted-foreground break-all">{errorMsg}</p>}
          </div>
        )}

        {status === "done" && msg && (
          <div className="panel p-6 text-center max-w-sm w-full">
            {msg.ok ? (
              <CheckCircle2 className="mx-auto size-14 text-success" />
            ) : (
              <XCircle className="mx-auto size-14 text-destructive" />
            )}
            <h3 className="mt-3 text-xl font-bold">{msg.title}</h3>
            <p className="mt-1 text-sm text-muted-foreground">{msg.desc}</p>
            {result?.slot && (
              <p className="mt-3 font-mono text-sm">Horário: {result.slot.slice(0, 5)}</p>
            )}
            <button
              onClick={onClose}
              className="mt-5 inline-flex items-center justify-center px-4 py-2 rounded-md bg-primary text-primary-foreground text-sm font-semibold hover:bg-primary/90"
            >
              Fechar
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
