import { useCallback, useEffect, useState } from "react";
import Cropper, { Area } from "react-easy-crop";

interface AvatarCropperProps {
  file: File;
  onCancel: () => void;
  onConfirm: (croppedFile: File) => void;
  isSaving?: boolean;
}

async function getCroppedBlob(imageSrc: string, area: Area, outSize = 512): Promise<Blob> {
  const image = await new Promise<HTMLImageElement>((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = "anonymous";
    img.onload = () => resolve(img);
    img.onerror = reject;
    img.src = imageSrc;
  });
  const canvas = document.createElement("canvas");
  canvas.width = outSize;
  canvas.height = outSize;
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("Canvas indisponível.");
  ctx.drawImage(
    image,
    area.x,
    area.y,
    area.width,
    area.height,
    0,
    0,
    outSize,
    outSize,
  );
  return new Promise<Blob>((resolve, reject) => {
    canvas.toBlob(
      (b) => (b ? resolve(b) : reject(new Error("Falha ao gerar imagem."))),
      "image/jpeg",
      0.85,
    );
  });
}

export function AvatarCropper({ file, onCancel, onConfirm, isSaving }: AvatarCropperProps) {
  const [src, setSrc] = useState<string>("");
  const [crop, setCrop] = useState({ x: 0, y: 0 });
  const [zoom, setZoom] = useState(1);
  const [area, setArea] = useState<Area | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    const url = URL.createObjectURL(file);
    setSrc(url);
    return () => URL.revokeObjectURL(url);
  }, [file]);

  const onCropComplete = useCallback((_: Area, pixels: Area) => {
    setArea(pixels);
  }, []);

  const handleConfirm = async () => {
    if (!area || !src) return;
    setBusy(true);
    try {
      const blob = await getCroppedBlob(src, area);
      const cropped = new File([blob], "avatar.jpg", { type: "image/jpeg" });
      onConfirm(cropped);
    } catch (e) {
      console.error(e);
      setBusy(false);
    }
  };

  const disabled = busy || isSaving;

  return (
    <div className="fixed inset-0 z-50 bg-background/95 backdrop-blur-sm flex flex-col">
      <div className="px-4 py-3 border-b border-border">
        <h2 className="text-sm font-semibold">Ajuste a foto</h2>
        <p className="text-xs text-muted-foreground">Arraste para reposicionar e use o zoom.</p>
      </div>
      <div className="relative flex-1 bg-black">
        {src && (
          <Cropper
            image={src}
            crop={crop}
            zoom={zoom}
            aspect={1}
            cropShape="round"
            showGrid={false}
            onCropChange={setCrop}
            onZoomChange={setZoom}
            onCropComplete={onCropComplete}
          />
        )}
      </div>
      <div className="p-4 space-y-3 border-t border-border">
        <div className="flex items-center gap-3">
          <span className="text-xs text-muted-foreground">Zoom</span>
          <input
            type="range"
            min={1}
            max={4}
            step={0.05}
            value={zoom}
            onChange={(e) => setZoom(Number(e.target.value))}
            className="flex-1"
          />
        </div>
        <div className="flex gap-2">
          <button
            type="button"
            onClick={onCancel}
            disabled={disabled}
            className="flex-1 px-3 py-2 rounded-md border border-border text-sm font-semibold hover:bg-muted disabled:opacity-60"
          >
            Cancelar
          </button>
          <button
            type="button"
            onClick={handleConfirm}
            disabled={disabled || !area}
            className="flex-1 px-3 py-2 rounded-md bg-primary text-primary-foreground text-sm font-semibold hover:bg-primary/90 disabled:opacity-60"
          >
            {disabled ? "Salvando..." : "Usar foto"}
          </button>
        </div>
      </div>
    </div>
  );
}
