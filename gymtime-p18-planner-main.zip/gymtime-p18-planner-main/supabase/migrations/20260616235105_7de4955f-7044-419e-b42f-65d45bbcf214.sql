CREATE OR REPLACE FUNCTION public.bookings_slot_counts(_date date, _gym public.gym_type)
RETURNS TABLE(slot_start time without time zone, count integer)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
  SELECT b.slot_start, COUNT(*)::int
  FROM public.bookings b
  WHERE b.booking_date = _date
    AND b.gym = _gym
  GROUP BY b.slot_start;
$function$;

CREATE OR REPLACE FUNCTION public.bookings_gym_counts(_date date)
RETURNS TABLE(gym public.gym_type, count integer)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
  SELECT b.gym, COUNT(*)::int
  FROM public.bookings b
  WHERE b.booking_date = _date
  GROUP BY b.gym;
$function$;

CREATE OR REPLACE FUNCTION public.public_bookings_listing(_date date)
RETURNS TABLE(id uuid, gym public.gym_type, slot_start time without time zone, user_id uuid, nome text, avatar_url text, company_id uuid, company_nome text)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
  SELECT b.id, b.gym, b.slot_start, b.user_id,
         p.nome, p.avatar_url, p.company_id, c.nome AS company_nome
  FROM public.bookings b
  LEFT JOIN public.profiles p ON p.id = b.user_id
  LEFT JOIN public.companies c ON c.id = p.company_id
  WHERE b.booking_date = _date
  ORDER BY b.slot_start ASC;
$function$;

REVOKE ALL ON FUNCTION public.bookings_slot_counts(date, public.gym_type) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.bookings_gym_counts(date) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.public_bookings_listing(date) FROM PUBLIC;

GRANT EXECUTE ON FUNCTION public.bookings_slot_counts(date, public.gym_type) TO authenticated;
GRANT EXECUTE ON FUNCTION public.bookings_gym_counts(date) TO authenticated;
GRANT EXECUTE ON FUNCTION public.public_bookings_listing(date) TO authenticated;
GRANT EXECUTE ON FUNCTION public.bookings_slot_counts(date, public.gym_type) TO service_role;
GRANT EXECUTE ON FUNCTION public.bookings_gym_counts(date) TO service_role;
GRANT EXECUTE ON FUNCTION public.public_bookings_listing(date) TO service_role;