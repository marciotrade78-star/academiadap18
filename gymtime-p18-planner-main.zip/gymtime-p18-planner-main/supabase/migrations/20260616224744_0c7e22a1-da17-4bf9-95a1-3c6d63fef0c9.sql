
-- Tighten SELECT on bookings and profiles; expose only needed data via SECURITY DEFINER RPCs

-- 1) Restrict SELECT on bookings to owner or admin
DROP POLICY IF EXISTS "Reservas visíveis a autenticados" ON public.bookings;
CREATE POLICY "Usuário vê própria reserva ou admin vê todas"
ON public.bookings
FOR SELECT
TO authenticated
USING (auth.uid() = user_id OR public.has_role(auth.uid(), 'admin'::app_role));

-- 2) Restrict SELECT on profiles to owner or admin
DROP POLICY IF EXISTS "Profiles visíveis a autenticados" ON public.profiles;
CREATE POLICY "Usuário vê próprio profile ou admin vê todos"
ON public.profiles
FOR SELECT
TO authenticated
USING (auth.uid() = id OR public.has_role(auth.uid(), 'admin'::app_role));

-- 3) Public listing for the reservations panel (returns only display-safe fields)
CREATE OR REPLACE FUNCTION public.public_bookings_listing(_date date)
RETURNS TABLE (
  id uuid,
  gym public.gym_type,
  slot_start time,
  user_id uuid,
  nome text,
  avatar_url text,
  company_id uuid,
  company_nome text
)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT b.id, b.gym, b.slot_start, b.user_id,
         p.nome, p.avatar_url, p.company_id, c.nome AS company_nome
  FROM public.bookings b
  LEFT JOIN public.profiles p ON p.id = b.user_id
  LEFT JOIN public.companies c ON c.id = p.company_id
  WHERE b.booking_date = _date
    AND auth.uid() IS NOT NULL
  ORDER BY b.slot_start ASC;
$$;

REVOKE ALL ON FUNCTION public.public_bookings_listing(date) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.public_bookings_listing(date) TO authenticated;

-- 4) Slot occupancy counts per gym (no PII)
CREATE OR REPLACE FUNCTION public.bookings_slot_counts(_date date, _gym public.gym_type)
RETURNS TABLE (slot_start time, count integer)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT b.slot_start, COUNT(*)::int
  FROM public.bookings b
  WHERE b.booking_date = _date
    AND b.gym = _gym
    AND auth.uid() IS NOT NULL
  GROUP BY b.slot_start;
$$;

REVOKE ALL ON FUNCTION public.bookings_slot_counts(date, public.gym_type) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.bookings_slot_counts(date, public.gym_type) TO authenticated;

-- 5) Per-gym daily total (no PII)
CREATE OR REPLACE FUNCTION public.bookings_gym_counts(_date date)
RETURNS TABLE (gym public.gym_type, count integer)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT b.gym, COUNT(*)::int
  FROM public.bookings b
  WHERE b.booking_date = _date
    AND auth.uid() IS NOT NULL
  GROUP BY b.gym;
$$;

REVOKE ALL ON FUNCTION public.bookings_gym_counts(date) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.bookings_gym_counts(date) TO authenticated;

-- 6) Lock down existing SECURITY DEFINER functions from anon
REVOKE EXECUTE ON FUNCTION public.has_role(uuid, public.app_role) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.has_role(uuid, public.app_role) TO authenticated;

REVOKE EXECUTE ON FUNCTION public.check_in_booking(public.gym_type) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.check_in_booking(public.gym_type) TO authenticated;
