-- Permitir até 6 usuários por slot
ALTER TABLE public.bookings DROP CONSTRAINT IF EXISTS bookings_gym_booking_date_slot_start_key;

CREATE OR REPLACE FUNCTION public.enforce_slot_capacity()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  cnt INTEGER;
BEGIN
  SELECT COUNT(*) INTO cnt
  FROM public.bookings
  WHERE gym = NEW.gym
    AND booking_date = NEW.booking_date
    AND slot_start = NEW.slot_start;
  IF cnt >= 6 THEN
    RAISE EXCEPTION 'slot_full: este horário já atingiu o limite de 6 usuários';
  END IF;
  RETURN NEW;
END;
$$;

REVOKE EXECUTE ON FUNCTION public.enforce_slot_capacity() FROM PUBLIC, anon, authenticated;

DROP TRIGGER IF EXISTS bookings_capacity_trg ON public.bookings;
CREATE TRIGGER bookings_capacity_trg
BEFORE INSERT ON public.bookings
FOR EACH ROW EXECUTE FUNCTION public.enforce_slot_capacity();