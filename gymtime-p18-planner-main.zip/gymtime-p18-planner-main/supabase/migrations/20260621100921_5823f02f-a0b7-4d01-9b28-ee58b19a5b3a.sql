
DROP POLICY IF EXISTS "Authenticated users can read realtime messages" ON realtime.messages;
DROP POLICY IF EXISTS "Authenticated can receive broadcast messages" ON realtime.messages;
DROP POLICY IF EXISTS "authenticated_realtime_select" ON realtime.messages;

-- Only allow subscribing to channels whose topic contains the user's uid.
-- Convention: name channels like "user:<auth.uid()>:..." or "<auth.uid()>:..."
CREATE POLICY "Users can only subscribe to own topics"
ON realtime.messages
FOR SELECT
TO authenticated
USING (
  realtime.topic() IS NOT NULL
  AND position((auth.uid())::text in realtime.topic()) > 0
);
