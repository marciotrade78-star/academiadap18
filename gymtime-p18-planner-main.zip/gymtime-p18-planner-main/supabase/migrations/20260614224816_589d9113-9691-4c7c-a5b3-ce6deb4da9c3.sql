DROP POLICY IF EXISTS "Avatars: usuários veem próprios" ON storage.objects;
CREATE POLICY "Avatars: autenticados veem todos"
ON storage.objects FOR SELECT
TO authenticated
USING (bucket_id = 'avatars');