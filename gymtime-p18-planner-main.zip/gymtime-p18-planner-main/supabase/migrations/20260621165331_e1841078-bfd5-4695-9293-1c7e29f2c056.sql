-- Fix 1: Remove permissive realtime policy
DROP POLICY IF EXISTS "Authenticated can receive realtime messages" ON realtime.messages;

-- Fix 2: Restrict profile updates so consent/audit columns cannot be falsified
DROP POLICY IF EXISTS "Usuário atualiza próprio profile" ON public.profiles;

CREATE POLICY "Usuário atualiza próprio profile"
ON public.profiles
FOR UPDATE
TO authenticated
USING (auth.uid() = id)
WITH CHECK (
  auth.uid() = id
  AND terms_accepted_at IS NOT DISTINCT FROM (SELECT terms_accepted_at FROM public.profiles WHERE id = auth.uid())
  AND terms_version IS NOT DISTINCT FROM (SELECT terms_version FROM public.profiles WHERE id = auth.uid())
  AND privacy_accepted_at IS NOT DISTINCT FROM (SELECT privacy_accepted_at FROM public.profiles WHERE id = auth.uid())
  AND privacy_version IS NOT DISTINCT FROM (SELECT privacy_version FROM public.profiles WHERE id = auth.uid())
  AND matricula IS NOT DISTINCT FROM (SELECT matricula FROM public.profiles WHERE id = auth.uid())
  AND email IS NOT DISTINCT FROM (SELECT email FROM public.profiles WHERE id = auth.uid())
);