
CREATE OR REPLACE FUNCTION public.bookings_slot_counts(_date date, _gym gym_type)
 RETURNS TABLE(slot_start time without time zone, count integer)
 LANGUAGE sql
 STABLE
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  SELECT b.slot_start, COUNT(*)::int
  FROM public.bookings b
  WHERE b.booking_date = _date
    AND b.gym = _gym
  GROUP BY b.slot_start;
$function$;

CREATE OR REPLACE FUNCTION public.bookings_gym_counts(_date date)
 RETURNS TABLE(gym gym_type, count integer)
 LANGUAGE sql
 STABLE
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  SELECT b.gym, COUNT(*)::int
  FROM public.bookings b
  WHERE b.booking_date = _date
  GROUP BY b.gym;
$function$;
