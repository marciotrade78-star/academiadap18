
-- 1. Tighten bookings SELECT: own bookings or admin
DROP POLICY IF EXISTS "Usuários veem reservas atuais e admins veem todas" ON public.bookings;
CREATE POLICY "Usuário vê próprias reservas ou admin vê todas"
ON public.bookings
FOR SELECT
TO authenticated
USING (auth.uid() = user_id OR has_role(auth.uid(), 'admin'::app_role));

-- 2. Tighten avatars storage SELECT to owner folder
DROP POLICY IF EXISTS "Avatars: autenticados veem todos" ON storage.objects;
CREATE POLICY "Avatars: usuários veem próprios"
ON storage.objects
FOR SELECT
TO authenticated
USING (
  bucket_id = 'avatars'
  AND (auth.uid())::text = (storage.foldername(name))[1]
);

-- 3. Realtime channel authorization: require authenticated subscription
ALTER TABLE realtime.messages ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Authenticated can receive realtime messages" ON realtime.messages;
CREATE POLICY "Authenticated can receive realtime messages"
ON realtime.messages
FOR SELECT
TO authenticated
USING (true);
