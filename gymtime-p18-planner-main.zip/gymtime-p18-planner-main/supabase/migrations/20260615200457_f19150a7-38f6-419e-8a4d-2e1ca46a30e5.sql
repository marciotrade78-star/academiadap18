
CREATE OR REPLACE FUNCTION public.handle_new_user()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  is_first BOOLEAN;
  v_company_id uuid;
  v_matricula text;
BEGIN
  v_company_id := NULLIF(NEW.raw_user_meta_data->>'company_id', '')::uuid;
  v_matricula := COALESCE(NEW.raw_user_meta_data->>'matricula', NEW.id::text);

  IF EXISTS (SELECT 1 FROM public.profiles WHERE matricula = v_matricula) THEN
    RAISE EXCEPTION 'matricula_duplicada: já existe um usuário com esta matrícula/SISPATE.'
      USING ERRCODE = 'unique_violation';
  END IF;

  BEGIN
    INSERT INTO public.profiles (id, nome, matricula, email, company_id)
    VALUES (
      NEW.id,
      COALESCE(NEW.raw_user_meta_data->>'nome', NEW.email),
      v_matricula,
      NEW.email,
      v_company_id
    );
  EXCEPTION
    WHEN unique_violation THEN
      RAISE EXCEPTION 'matricula_duplicada: já existe um usuário com esta matrícula/SISPATE.'
        USING ERRCODE = 'unique_violation';
  END;

  SELECT NOT EXISTS (SELECT 1 FROM public.user_roles WHERE role = 'admin') INTO is_first;
  INSERT INTO public.user_roles (user_id, role)
  VALUES (NEW.id, CASE WHEN is_first THEN 'admin'::app_role ELSE 'user'::app_role END);
  RETURN NEW;
END;
$function$;
