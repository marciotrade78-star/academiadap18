
GRANT SELECT ON public.companies TO anon;
DROP POLICY IF EXISTS "Empresas visíveis a autenticados" ON public.companies;
CREATE POLICY "Empresas visíveis a todos" ON public.companies
  FOR SELECT TO anon, authenticated USING (true);
