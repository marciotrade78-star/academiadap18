
ALTER TABLE public.bookings ADD COLUMN IF NOT EXISTS checked_in_at timestamptz;

CREATE OR REPLACE FUNCTION public.check_in_booking(_gym gym_type)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_booking public.bookings%ROWTYPE;
  v_now timestamptz := now();
  v_today date := (v_now AT TIME ZONE 'America/Sao_Paulo')::date;
  v_local_time time := (v_now AT TIME ZONE 'America/Sao_Paulo')::time;
BEGIN
  IF auth.uid() IS NULL THEN
    RAISE EXCEPTION 'not_authenticated';
  END IF;

  SELECT * INTO v_booking
  FROM public.bookings
  WHERE user_id = auth.uid()
    AND gym = _gym
    AND booking_date = v_today
  LIMIT 1;

  IF NOT FOUND THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'no_booking');
  END IF;

  IF v_booking.checked_in_at IS NOT NULL THEN
    RETURN jsonb_build_object('ok', true, 'reason', 'already', 'slot', v_booking.slot_start);
  END IF;

  IF v_local_time < (v_booking.slot_start - interval '10 minutes')
     OR v_local_time > (v_booking.slot_start + interval '45 minutes') THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'out_of_window', 'slot', v_booking.slot_start);
  END IF;

  UPDATE public.bookings SET checked_in_at = v_now WHERE id = v_booking.id;
  RETURN jsonb_build_object('ok', true, 'reason', 'confirmed', 'slot', v_booking.slot_start);
END;
$$;

GRANT EXECUTE ON FUNCTION public.check_in_booking(gym_type) TO authenticated;
