DROP POLICY IF EXISTS "Usuário vê própria reserva ou admin vê todas" ON public.bookings;

CREATE POLICY "Usuários veem reservas atuais e admins veem todas"
ON public.bookings
FOR SELECT
TO authenticated
USING (
  has_role(auth.uid(), 'admin'::public.app_role)
  OR auth.uid() = user_id
  OR booking_date BETWEEN (now() AT TIME ZONE 'America/Sao_Paulo')::date
                      AND ((now() AT TIME ZONE 'America/Sao_Paulo')::date + 1)
);

GRANT SELECT ON public.bookings TO authenticated;

CREATE OR REPLACE FUNCTION public.bookings_slot_counts(_date date, _gym public.gym_type)
RETURNS TABLE(slot_start time without time zone, count integer)
LANGUAGE sql
STABLE
SECURITY INVOKER
SET search_path TO 'public'
AS $function$
  SELECT b.slot_start, COUNT(*)::int
  FROM public.bookings b
  WHERE b.booking_date = _date
    AND b.gym = _gym
  GROUP BY b.slot_start;
$function$;

CREATE OR REPLACE FUNCTION public.bookings_gym_counts(_date date)
RETURNS TABLE(gym public.gym_type, count integer)
LANGUAGE sql
STABLE
SECURITY INVOKER
SET search_path TO 'public'
AS $function$
  SELECT b.gym, COUNT(*)::int
  FROM public.bookings b
  WHERE b.booking_date = _date
  GROUP BY b.gym;
$function$;

REVOKE ALL ON FUNCTION public.bookings_slot_counts(date, public.gym_type) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.bookings_gym_counts(date) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.bookings_slot_counts(date, public.gym_type) TO authenticated;
GRANT EXECUTE ON FUNCTION public.bookings_gym_counts(date) TO authenticated;
GRANT EXECUTE ON FUNCTION public.bookings_slot_counts(date, public.gym_type) TO service_role;
GRANT EXECUTE ON FUNCTION public.bookings_gym_counts(date) TO service_role;